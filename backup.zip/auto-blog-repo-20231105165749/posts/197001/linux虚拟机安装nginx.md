---
---
title:  linux虚拟机安装nginx+反向代理+负载均衡
date: 2021-10-09
updated: 2021-10-09
tags:
- Linux
- Nginx
- 教程
categories:
- Linux
ai: true
---
  #  linux虚拟机安装nginx+反向代理+负载均衡
# 

# 安装nginx

**c++编译环境**

```
yum install gcc-c++					//安装c++编译环境
```

**模块依赖库**

```
yum -y install pcre* openssl* zlib*  //安装模块依赖库
```



**下载**

```
wget http://nginx.org/download/nginx-1.21.3.tar.gz
```

**解压 /usr/local**

```
tar -zxvf nginx-1.21.3.tar.gz -C /usr/local
```

**在/usr/local下生成一个nginx目录**

```
cd /usr/local/nginx-1.21.3
./configure
make and make install
```

**启动**

```
cd /usr/local/nginx/sbin/
./nginx  
```

**关闭**

```
cd /usr/local/nginx/sbin
./nginx -s stop				//快速停止 先找到进程 id 在 kill 进程


cd /usr/local/nginx/sbin
./nginx -s quit			//将正在处理的网络请求处理完成，不接收新的请求，之后关闭连接

//关闭
./nginx -s quit
/usr/local/nginx/sbin/nginx -s quit
```

**重启**

```bash
//重新加载配置文件
./nginx -s reload	
/usr/local/nginx/sbin/nginx -s reload

./nginx -t -c  /usr/local/nginx/conf/nginx.conf	//检查配置文件语法是否正确
```



# 反向代理

反向代理qwer.top 到 127.0.0.1:8080

修改本地 hosts 文件，将qwer.top 映射到 127.0.0.1

```
vim /etc/hosts
127.0.0.1  qwer.top 
```

访问：`qwe.top:8080`

**配置nginx.conf**

`vim /usr/local/nginx/conf/nginx.conf`

```
server {
         listen       80;
         server_name  qwer.top; #可以有多个名称，中间用空格隔开
 
         location / { 			#用于匹配 URL
             proxy_pass http://127.0.0.1:8080; 		#用于设置被代理服务器的地址
             index  index.html index.htm index.jsp; #用于设置网站的默认首页
         }
     }
```

访问：`qwer.top`

```
listen *:80 | *:8080 		#监听所有80端口和8080端口
listen  IP_address:port   	#监听指定的地址和端口号
listen  IP_address     		#监听指定ip地址所有端口
listen port     			#监听该端口的所有IP连接
```





# 负载均衡

同时启动两个tomcat：tomcat1、tomcat2

特别要注意：不要设置CATALINA_HOME
分别修改安装目录下的conf子目录中的server.xml文件：

a.修改tomcat1   http访问端口 `vim ./tomcat1/conf/server.xml`

```xml
<Server port="8095" shutdown="SHUTDOWN">
```

```xml
<Connector port="8091" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" />
```



修改tomcat2   http访问端口 `vim ./tomcat2/conf/server.xml`

```xml
<Server port="8096" shutdown="SHUTDOWN">
```

```xml
<Connector port="8092" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" />
```

**启动tomcat**

`./tomcat1/bin/startup.sh`

`./tomcat2/bin/startup.sh`

**访问**

`127.0.0.1:8091`

`127.0.0.1:8092`





**实现普通轮询**

配置文件nginx.conf  `/usr/local/nginx/conf/`

```bash
    
    #浏览器地址：qwer.top
    #代理地址：http://testnginx
    #负载均衡： upstream testnginx{
    #            server 127.0.0.1:8091;
    #            server 127.0.0.1:8092;
    
    upstream testnginx{
      server 127.0.0.1:8091 weight=2;
      server 127.0.0.1:8092 weight=1;
    }
    
    server{
	    listen	80;
	    server_name	qwer.top;
	
     location /{
	    proxy_pass	  http://testnginx;
	    index	      index.html index.jsp index.html;
	  }
   }
```

**weight权重 默认为1**

**启动nginx**

```
cd /usr/local/nginx/sbin/
./nginx
```

**访问**

`qwer.top`
 