---
---
abbrlink: ''
ai: true
categories:
- Linux
date: '2021-09-08 00:00:00'
tags:
- Linux
- finalshell
title: 安装finalshell 连接 linux
updated: 2023-9-7T21:18:23.580+8:0
---
# 安装finalshell

finalshell  http://www.hostbuf.com/t/988.html

> 连接 linux

我们需要IP地址和端口链接，本机的IP（127.0.0.1）localhost。

就必须使用虚拟机和主机建立一个局域网，能够互相连接上。

nat，创建局域网

255.255.255  子网掩码

192.168.2 .100

192.168.2 网络号

100 主机号

# 查看网络号和子网掩码

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041152000.png)

**更改设置**

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041583000.png)

# 查看ip范围

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041690000.png)

# 查看网关号

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041766000.png)

# ip addr 查看IP地址

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041887000.png)

# 配置网络

```
cd /etc/sysconfig/network-scripts/ 
ll	查看列表
vi ifcfg-ens33
```

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041950000.png)

点击i，进入编辑模式，左下角出现insert

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041994000.png)

# 修改ifcfg-ens33

```
# 修改以下内容 
BOOTPROTO=static 
onboot=yes 
# 增加以下内容 
IPADDR=192.168.120.200
NETMASK=255.255.255.0 
GATEWAY=192.168.120.2
```

**先按 esc 退出编辑模式，再按 shfit+: 进入命令模式，再输入 wq ，点击回车保存并退出。**

w:保存	q:退出

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631044468000.png)

重启Centos7网卡

```
systemctl restart network
```

# cmd查看 ip地址

```
ipconfig
```

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042561000.png)

# 查看本地网卡

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042674000.png)

# 使用ping

```
ping 192.168.120.200
```

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042780000.png)

# ping通后打开FinalShell

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042906000.png)

确定双击打开

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042947000.png)

最后连接成功

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631042996000.png)
