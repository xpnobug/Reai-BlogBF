---
---
ai: true
categories:
- Java
date: '2021-09-29'
tags:
- Java
title: 使用idea远程连接部署SpringBoot项目
updated: 2023-9-7T21:17:50.474+8:0
---
# 使用idea远程连接部署SpringBoot项目

**idea连接**

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908764000.png)

**输入ip地址测试连接**

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908770000.png)

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908776000.png)

**打开终端**

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908799000.png)

# 在终端开启mysql redis

### **连接mysql**

1.开启mysql并开启3306端口

```
service mysql start  	--开启mysql

service mysqld status 	--查看状态

lsof -i:3306			--查看mysql服务是否在运行

ps -ef | grep mysql		--查看mysql进程
```

2.开启3306端口

```
firewall-cmd --add-port=3306/tcp  	-- 添加端口

firewall-cmd --list-ports 			-- 查看端口列表

systemctl status firewalld			-- 查看防火墙端口
```

3.测试连接mysql

### **连接redis**

1.查看redis.conf文件

`grep -v "#" ` 排除 #

```
cat /usr/local/redis6.2.5/redis.conf | grep -v "#"
```

`设置redis密码与redis.conf文件的密码一直`

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908806000.png)

2.启动redis开放6379端口

```
redis-server /usr/local/redis6.2.5/redis.conf  	--启动redis

lsof -i:6379									--查看redis服务是否在运行

firewall-cmd --zone=public --add-port=6379/tcp  --开放6379端口

firewall-cmd --list-ports 						-- 查看端口列表
```

3.测试连接redis

1.对应ip地址

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908814000.png)

# linux运行java项目

## **项目打包**

### 父级pom

```
    <modules>
        <module>itrip-beans</module>
        <module>itrip-utils</module>
        <module>itrip-dao</module>
        <module>itrip-search</module>
        <module>itrip-trade</module>
        <module>itrip-auth</module>
        <module>itrip-biz</module>
    </modules>
```

```
<!--父模块打包形式：pom-->
<packaging>pom</packaging>
```

```
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                    <encoding>${project.build.sourceEncoding}</encoding>
                </configuration>
            </plugin>
        </plugins>
    </build>
```

### 在父级项目中点击package 打包所有子项目

```
[INFO] Reactor Summary for itripdb 0.0.1-SNAPSHOT:
[INFO] 
[INFO] itripdb ............................................ SUCCESS [  0.010 s]
[INFO] itrip-beans ........................................ SUCCESS [  7.181 s]
[INFO] itrip-utils ........................................ SUCCESS [  2.869 s]
[INFO] itrip-dao .......................................... SUCCESS [  2.474 s]
[INFO] itrip-search ....................................... SUCCESS [  5.724 s]
[INFO] itrip-trade ........................................ SUCCESS [  3.087 s]
[INFO] itrip-auth ......................................... SUCCESS [  6.553 s]
[INFO] itrip-biz .......................................... SUCCESS [  4.312 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time:  32.991 s
[INFO] Finished at: 2021-09-29T16:38:05+08:00
[INFO] ------------------------------------------------------------------------
```

### 找到打包好的jar文件

**放入linux 在opt下创建project文件夹  /opt/project**

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632908824000.png)

### 运行项目

```
 cd /opt/project
 java -jar itrip-auth-0.0.1-SNAPSHOT.jar 
```

### 测试登录存入token

```
http://192.168.120.200:8081/auth/api/login?password=123&userCode=qwe
```

```
{
  "code": 200,
  "message": "成功",
  "data": {
    "token": "token:PC-unknown-76d80224611fc919a5d54f0ff9fba446-38-20210929165811-40f992",
    "expireTime": 1632905892381,
    "creaTime": 1632905892321
  }
}
```

关闭防火墙

```
systemctl stop firewlld
```

查看防火墙状态

```
 systemctl status firewalld
```

查看进程

```
ps -ef | grep mysql
```
