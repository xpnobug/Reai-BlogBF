---
---
abbrlink: ''
ai: true
categories:
- Java
date: '2022-11-20 18:36:04'
tags:
- Java
- Map
title: 集合之Map集合
updated: 2023-9-7T21:21:22.431+8:0
---
**什么是Map集合**

* Map集合是一种双列集合，每个元素都包含两个数据
* Map集合的每个元素的格式：key=value(键值对元素)
* Map集合也被称为“键值对集合”
* Map集合的完整格式:{key1=value1,key2=value2,key3=value3….}

#### Map集合的体系结构

* Map集合的特点是由键来决定的
* Map集合的键是无序、不重复，无索引的，值不做要求可以重复
* Map集合后面重复的键对应的值会覆盖前面重复键的值
* Map集合的键值对都可以为null

**Map集合实现类的特点**

#### HashMap的特点

* HashMap是Map里的一个实现类。它的键是无序、不重复、无索引的
* HashMap跟HashSet底层原理是一样的，都是哈希表的结构，只是HashMap的每个元素包含两个值
* Set集合的底层原理就是Map实现的。只是Set集合中只要键数据，不要值数据
* 也是依赖hashCode方法和equal方法保证键的唯一

```java
        //1.创建Map集合对象
        Map<String,Integer> maps = new HashMap<>();
        //2.添加数据
        maps.put("Macbook Pro",1);
        maps.put("Apple Watch",2);
        System.out.println(maps); //输出 {Apple Watch=2, Macbook Pro=1}
```

#### LinkedHashMap的特点

* 有序、不重复、无索引
* 有序指的是保证存储和取出元素的顺序一致
* 底层依然是哈希表，只是每个键值对又额外多了双链表的机制记录存储的顺序

```java
        //1.创建Map集合对象
        Map<String,Integer> maps = new LinkedHashMap<>();
        //2.添加数据
        maps.put("Macbook Pro",1);
        maps.put("Apple Watch",2);
        System.out.println(maps); //输出 {Macbook Pro=1, Apple Watch=2}
```

#### TreeMap的特点

* 不重复、无索引、可排序
* 按照键数据的大小默认升序排序，只能对键排序
* TreeMap集合必须要排序，可以默认排序，也可以将键按照指定的规则进行排序

---

#### **Map集合常用API**

```java
        Map<String,Integer> maps = new LinkedHashMap<>();

        /**
         * V put(K key, V value);
         * Map集合添加元素
         * 参数1：数据的键
         * 参数2：数据的值
         */
        maps.put("Macbook Pro",1);
        maps.put("Apple Watch",2);

        /**
         * void clear();
         * 清空集合
         */
        //maps.clear();

        /**
         *  boolean isEmpty();
         *  判断集合是否为空
         */
        maps.isEmpty();

        /**
         * V get(Object key);
         * 根据键获取对应的值
         */
        maps.get("Apple Watch");

        /**
         * V remove(Object key);
         * 根据键删除对应的元素
         */
        maps.remove("Apple Watch");

        /**
         * boolean containsKey(Object key);
         * 判断是否包含某个键
         */
        maps.containsKey("Apple Watch");

        /**
         * boolean containsValue(Object value);
         * 判断是否包含某个值
         */
        maps.containsValue(2);

        /**
         * Set<K> keySet();
         * 获取全部键的集合
         * 因为键的特性，就是Set集合的特性：无序、不重复、无索引。
         * 所以返回的键使用Set集合保存
         */
        Set<String> strings = maps.keySet();

        /**
         *  Collection<V> values();
         *  获取全部值的集合
         *  由于值是可以重复的，所以用Collection集合接收值
         */
        Collection<Integer> values = maps.values();

        /**
         * int size();
         * 获取集合的大小
         */
        maps.size();

  
        Map<String, Integer> maps2 = new HashMap<>();
        maps2.put("Lenovo PC",1);
        /**
         * void putAll(Map<? extends K, ? extends V> m)
         * 合并其他Map集合
         */
        maps.putAll(maps2);
```

---

#### **Map集合的遍历方式**

1. 先获取Map集合的全部键的Set集合，然后遍历Set集合，通过键提取对应值

```java
 	Map<String,Integer> maps = new LinkedHashMap<>();
        maps.put("Macbook Pro",1);
        maps.put("Apple Watch",2);
    
        //1.获取到集合的全部键
        Set<String> keys = maps.keySet();
    
        //2.遍历键
        for (String key : keys) {
            //3.通过键，获取到值
            System.out.println(maps.get(key));
        }
```

2. 将Map集合中的键值对当做一个整体，先把Map集合转换成Set集合，Set集合中每个元素都是键值对实体类型。然后遍历Set集合，提取键以及提取值

```java
        /*    
        1.将Map集合转换成Set集合
        Set集合中的元素，是封装了Map集合中每个元素Key和value的Entry对象
        */
        Set<Map.Entry<String, Integer>> entries = maps.entrySet();

        //遍历Set集合，获取它里面的元素：Entry<Key,Value>
        for (Map.Entry<String, Integer> entry : entries) {
            //通过Entry对象的，getKey和getValue方法,获取到Map集合的键和值
        System.out.println(entry.getKey()+entry.getValue());
        }
```

---

#### **不可变集合**

* 不可以被修改的集合
* 集合的数据在创建的时候提供，在整个生命周期中都不可修改，否则报错
* 在List、Set、Map接口中，都存在of方法，可以创建一个不可变集合
