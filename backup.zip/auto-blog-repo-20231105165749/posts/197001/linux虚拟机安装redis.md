---
---
title: linux虚拟机安装redis-6.2.5
date: 2021-09-28
updated: 2021-09-28
tags:
- Linux
- Redis
- 教程
categories:
- Linux
ai: true
---
 # linux虚拟机安装redis-6.2.5



# 获取共享文件

` ls /mnt/hgfs/文件名`

`cd /mnt/hgfs/文件名`

# 解压

```
 tar -xvf redis-6.2.5.tar.gz -C /usr/local

 mv redis-6.2.5 ./redis6.2.5
```

**make会报错**

先使用

`yum install gcc` ---安装gcc依赖

`make MALLOC=libc` ---进行编译

`make iinstall` ---编译后安装

**客户端启动**  cd /src

`./redis-server`

`./redis-cli`



```
yum install 报错：Could not retrieve mirrorlist http://mirrorlist.centos.org
```

**1.查看yum是否安装成功，输入yum**

**2.网卡配置**

**ONBOOT=YES 配置完重启**

3.**验证配置resolv.conf是否配置**

使用vi指令跳转到resolv.conf文件那里: **vi /etc/resolv.conf**

文件其他内容注释掉，加上

**nameserver dns网络地址**

**search localdomain**



# 修改redis.conf

```
注释 bing 127.0.0.1

修改 requirepass foobared ---requirepass 123456

修改 daemonized --yes

修改 protected-mode --no
```

# 启动redis

```
启动redis
/usr/local/redis6.2.5/src/redis-cli
使用密码登录
/usr/local/redis6.2.5/src/redis-cli -a 123456
```



# 开启6379端口

关闭防火墙

```
 systemctl status firewalld 
```

查看6379端口

```
lsof -i:6379
```

查看 redis

```
ps -ef |grep redis
```



开启6379端口

```
# firewall-cmd --zone=public --add-port=6379/tcp --permanent` `#显示``success
```

重启防火墙

```
# firewall-cmd --reload` `#显示``success
```

检查端口是否开启

```
# firewall-cmd --query-port=6379/tcp` `#显示``yes
```

```
firewall-cmd --list-ports//端口列表

systemctl status firewalld//查看防火墙端口
```



# 远程连接

运行配置文件

`redis-server /usr/local/redis6.2.5/redis.conf`

或

`./src/redis-server ./redis.conf`





