---
---
ai: true
categories:
- Mysql
date: '2021-07-05T15:31:42+08:00'
tags:
- Mysql
title: 安装MySQL 社区服务器 8.0.25
updated: 2023-9-7T21:18:12.338+8:0
---
![](https://b3logfile.com/bing/20210622.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1.下载

下载之前干净卸载低版本mysql

1、在控制面板中卸载mysql软件
![](https://img.jbzj.com/file_images/article/201808/2018082116165373.png)

2、卸载过后删除C:\Program Files (x86)\MySQL该目录下剩余了所有文件，把mysql文件夹也删了

3、windows+R运行“regedit”文件，打开注册表

4、删除注册表：HKEY_LOCAL_MACHINE\SYSTEM\ControlSet001\Services\Eventlog\Application\MySQL文件夹
![](https://img.jbzj.com/file_images/article/201808/2018082116165375.png)

5、删除HKEY_LOCAL_MACHINE\SYSTEM\ControlSet002\Services\Eventlog\Application\MySQL文件夹，如果没有可以不用删除。

最好重启下电脑，重新安装8.0.25就可以了。

**开始下载MySQL 社区服务器 8.0.25**

[MySQL 社区服务器 8.0.25 https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)

## 2.配置解压文件

文件解压到一个能找到的目录下即可
(解压后在里边创建my.ini文件)

![my.ini](https://img.jbzj.com/file_images/article/202009/20200903105831106.png)
打开文件,将下面的代码粘贴复制进去

```
[mysqld]
# 设置3306端口
port=3306
# 设置mysql的安装目录
basedir=D:\Program Files\MySQL
# 设置mysql数据库的数据的存放目录
datadir=D:\Program Files\MySQL\Data
# 允许最大连接数
max_connections=200
# 允许连接失败的次数。这是为了防止有人从该主机试图攻击数据库系统
max_connect_errors=10
# 服务端使用的字符集默认为UTF8
character-set-server=utf8mb4
# 创建新表时将使用的默认存储引擎
default-storage-engine=INNODB
# 默认使用“mysql_native_password”插件认证
#mysql_native_password
default_authentication_plugin=mysql_native_password
[mysql]
# 设置mysql客户端默认字符集
default-character-set=utf8mb4
[client]
# 设置mysql客户端连接服务端时默认使用的端口
port=3306
default-character-set=utf8mb4
```

## 3.环境配置

右击我的电脑,找到属性》高级系统设置》环境变量

新建mysql
变量值：D:\Program Files\MySQL\mysql-8.0.25-winx64\bin

![image.png](https://b3logfile.com/file/2021/07/image-5be43acd.png)
然后确定

## 4.安装

以管理员身份运行cmd

1. 输入`cd D:\Program Files\MySQL\mysql-8.0.25-winx64\bin`(后面改成自己bin目录的地址)
2. 输入`mysqld --initialize --console`,出现如下画面则为成功,请务必记住末尾密码：**root@localhost: d<FZgkuR1-uI**
3. 然后输入`mysqld -install mysql`
4. 最后输入`net start mysql`启动mysql
   ![image.png](https://b3logfile.com/file/2021/07/image-42fff1a2.png)

**`执行报错`**

> 找不到VCRUNTIME140_1.dll
>
> 进入下载：https://cn.dll-files.com/vcruntime140_1.dll.html
>
> 放置C:\Windows\System32

## 5.更改密码

`mysql -u root -p`先输入初始密码**root@localhost: d<FZgkuR1-uI**

```
ALTER USER 'root'@'localhost' IDENTIFIED BY '新密码';
```

![image.png](https://b3logfile.com/file/2021/07/image-208bf7b5.png)

```

 
```
