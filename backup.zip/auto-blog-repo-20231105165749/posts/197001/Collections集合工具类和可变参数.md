---
---
abbrlink: ''
categories: []
cover: http://p4.qhimg.com/bdm/1600_900_85/t0108d784eae9160a45.jpg
date: '2022-11-20 18:11:43'
tags: Java
title: Collections集合工具类和可变参数
updated: '2022-11-20 18:19:12'
ai: true
---
**可变参数**

* 可变参数用在形参中可以接收多个数据
* 可变参数的格式：数据类型… 参数名称

**可变参数的作用**

* 传输参数十分灵活，可以不传输参数，也可以传输一个或多个参数，或传输一个数组
* 一个方法形参列表中可变参数只能有一个，并且可变参数必须放在参数列表的最后面

```java
    @Test
    public void testParams(){
        //不传参数
        sum(); //输出 0 []
        //传多个参数
        sum(1,2,3); //输出 3 [1, 2, 3]
        //传数组
        sum(new int[]{1,2,3}); //输出 3 [1, 2, 3]
    }

    /**
     * 注意事项：
     *  1.一个方法，形参列表中可变参数只能有一个
     *  2.可变参数必须放在参数列表的最后面
     */

    public static void sum(int... nums){
        //可变参数在方法内部其实就是一个数组
        System.out.println(nums.length);
        System.out.println(Arrays.toString(nums));
    }
```

---

#### **Collections集合工具类**

* java.utils.Collections:是集合工具类
* 该工具类并不属于集合，是用来操作集合的工具类

**常用方法**

```java
        List<String> lists = new ArrayList<>();

        /**
         * public static <T> boolean addAll(Collection<? super T> c, T... elements)
         * 给集合对象批量添加元素
         * 第一个参数是要添加元素的集合
         * 后面是可变参数，参数值是需要添加进集合的元素
         */
        Collections.addAll(lists,"zlprime","study","everyDay");

        /**
         * public static void shuffle(List<?> list)
         * 用于打乱集合中的元素顺序，只能打乱List集合元素
         * 参数值是需要打乱的集合
         */
        Collections.shuffle(lists);

        /**
         * public static <T extends Comparable<? super T>> void sort(List<T> list)
         * 对List集合中的数据进行排序，只有具有值特性的数据才能进行排序
         * 引用类型的数据无法排序，会直接报错
         */
        Collections.sort(lists);

        /**
         * public static <T> void sort(List<T> list, Comparator<? super T> c)
         * 根据自定义规则，对引用类型的元素进行排序
         * 参数一是需要排序的集合
         * 参数二是自定义的排序规则
         */
        Collections.sort(lists, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return 0;
            }
        });
```

转自[ https://www.zlprime.cn/archives/1561.html](https://www.zlprime.cn/archives/1561.html)
