---
---
ai: true
categories:
- npm
date: 2023-7-15T21:45:15.974+8:0
excerpt: 这篇文章介绍了npm和其作为nodejs的包管理工具的作用。npm是javascript著名的包管理工具，是前端模块化下的一个标志性产物。它能帮助开发者快速发布和管理自己的代码包。文章还提到了通过npm可以在几分钟内发布自己的npm包的方法。
tags:
- npm
title: 发布一个npm包
updated: 2023-9-7T21:17:3.680+8:0
---
# 五分钟发布npm包

# **什么是npm?**

> NPM（node package manager）是nodejs的包管理工具。

> npm是javascript著名的**包管理工具**，是**前端模块化**下的一个标志性产物**通过npm下载模块，复用已有的代码，提高工作效率**

# 发布npm包

要开始使用 npm，可以[创建一个帐户](https://www.npmjs.com/signup)，该[帐户](https://www.npmjs.com/signup)可在http://www.npmjs.com/~*yourusername * 上获得。

设置 npm 帐户后，下一步是使用命令行界面 (CLI)[安装 npm](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)。我们期待看到你创造的东西！

##### **1、创建一个npm的账号**

发布包之前你必须要注册一个npm的账号

##### **2、初始化一个简单的项目发布**

- 本地创建一个文件夹：**例如：`hexo-tool-cc`**	名字不能和npm上已经存在的一样，会推送不上去
- 执行命令进入目录: **cd hexo-tool-cc**
- 执行**npm init** 初始化项目。默认一路回车

```cmd
package name: (hexo-tool-cc)
version: (1.0.0)
description:
entry point: (index.js)
test command:
git repository:
keywords:
author:
license: (ISC)
About to write to D:\桌面\npm\hexo-tool-cc\package.json:

{
  "name": "tool",
  "version": "1.0.0",
  "description": "",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC"
}
Is this OK? (yes) 


默认字段简介：
name：发布的包名，默认是上级文件夹名。不得与现在npm中的包名重复。包名不能有大写字母/空格/下滑线!
version：你这个包的版本，默认是1.0.0。对于npm包的版本号有着一系列的规则，模块的版本号采用X.Y.Z的格式，具体体现为：
  1、修复bug，小改动，增加z。
  2、增加新特性，可向后兼容，增加y
  3、有很大的改动，无法向下兼容,增加x
description：项目简介
mian：入口文件，默认是Index.js，可以修改成自己的文件 
scripts：包含各种脚本执行命令
test：测试命令。
author：写自己的账号名
license：这个直接回车，开源文件协议吧，也可以是MIT，看需要吧。
```

在**`hexo-tool-cc`**文件夹中创建一个文件名为`index.js`的文件，简单的写了一下内容。

```js
!function(){
  console.log(`hello npm`)
}()
```

# **第一次发布包**

在终端输入`npm adduser`，提示输入用户名，密码和邮箱，然后将提示创建成功.
【注意】npm adduser成功的时候默认你已经登陆了

```cmd
>npm adduser
Username: 用户名
Password: 密码
Email: (this IS public) 邮箱
Logged in as 用户名 on https://registry.npmjs.org/.
```

最后一行显示登录信息，as 后面是用户名。on 后是源地址，如果不是[https://registry.npmjs.org/](https://link.segmentfault.com/?url=https%3A%2F%2Fregistry.npmjs.org%2F)，比如是淘宝源，请切换。

## 修改源地址为淘宝 NPM 镜像

```tcl
npm config set registry http://registry.npm.taobao.org/
```

## 修改源地址为官方源

```arduino
npm config set registry https://registry.npmjs.org/
```

# **非第一次发布包**

在终端输入npm login，然后输入你创建的账号和密码，和邮箱，登陆

# **npm publish 发布包**

```cmd
>npm publish
npm notice
npm notice package: hexo-tool-cc@1.0.0
npm notice === Tarball Contents ===
npm notice 60B  index.js
npm notice 208B package.json
npm notice === Tarball Details ===
npm notice name:          hexo-tool-cc
npm notice version:       1.0.0
npm notice filename:      hexo-tool-cc-1.0.0.tgz
npm notice package size:  336 B
npm notice unpacked size: 268 B
npm notice shasum:        c156a15882cae9f17894b688f791be8fb4fd93f2
npm notice integrity:     sha512-mYDd8l8QbHpNW[...]7OmbSt3Mc3ZyQ==
npm notice total files:   2
npm notice
+ hexo-tool-cc@1.0.0
```

# **查询发布的包**

> 到npm官网全局搜索即可

# **安装使用方式**

> 和其他包使用方式一致，具体使用可以看**源码介绍**或者**README.md**。

# **如何撤销发布的包**

**终端执行 `npm unpublish`**

```cmd
ps:
npm unpublish hexo-tool-cc@1.0.0 删除某个版本
npm unpublish hexo-tool-cc --force 删除整个npm市场的包
```

**撤包推荐用法：**
`npm unpublish`的推荐替代命令：

```
npm deprecate <pkg>[@<version>] <message>
```

使用这个命令，并不会在社区里撤销你已有的包，但会在任何人尝试安装这个包的时候得到警告
例如：

```
npm deprecate hexo-tool-cc '这个包我已经不再维护'
```

【注意】如果报权限方面的错，加上--force

# **发布错误**

```cmd
>npm publish
npm notice
npm notice package: hexo-tool-cc@1.0.0
npm notice === Tarball Contents ===
npm notice 60B  index.js
npm notice 200B package.json
npm notice === Tarball Details ===
npm notice name:          tool
npm notice version:       1.0.0
npm notice filename:      tool-1.0.0.tgz
npm notice package size:  330 B
npm notice unpacked size: 260 B
npm notice shasum:        cea7ffbf9f28f81fc530d94da3891779f895ee6d
npm notice integrity:     sha512-3TuKOdWhhRHFI[...]WJCL9T9OUmAgg==
npm notice total files:   2
npm notice
npm ERR! code E403
npm ERR! 403 403 Forbidden - PUT https://registry.npmjs.org/tool - You do not have permission to publish "hexo-tool-cc". Are you logged in as the correct user?
npm ERR! 403 In most cases, you or one of your dependencies are requesting
npm ERR! 403 a package version that is forbidden by your security policy, or
npm ERR! 403 on a server you do not have access to.

npm ERR! A complete log of this run can be found in:
npm ERR!     C:\Program Files\nodejs\node_cache\_logs\2021-09-09T08_21_00_032Z-debug.log
```

1.可能需要提高版本号

2.确保登录的用户账号正确

3.名字不能和npm上已经存在的一样

4.删除npm市场的包同名的24小时后才能重新发布

```stata
>npm publish
npm ERR! publish Failed PUT 403
npm ERR! code E403
npm ERR! hexo-tool-cc cannot be republished until 24 hours have passed. : hexo-tool-cc

npm ERR! A complete log of this run can be found in:
npm ERR!      C:\Program Files\nodejs\node_cache\_logs\2021-09-09T08_21_00_032Z-debug.log
```
