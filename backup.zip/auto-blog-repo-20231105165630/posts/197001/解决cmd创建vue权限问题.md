---
---
categories:
- - Vue
date: '2023-07-15T21:26:34.547807+08:00'
excerpt: 这篇文章介绍了如何解决在cmd中创建vue时可能遇到的权限问题。作者提到了一些解决方法，包括删除.npmrc文件、清空npm缓存以及查看npm使用的镜像地址。文章内容较为简短，具体步骤可能需要参考完整的文章。
tags:
- Vue
- Node
title: 解决cmd创建vue权限问题
updated: 2023-9-7T21:21:3.572+8:0
---
## 解决cmd创建vue权限问题

**C:\\Users\\dell    删除 `.npmrc`**

![image-20211015211404894](https://cdn.jsdelivr.net/gh/xpnobug/CDN/img/hpp_upload/image-20211015211404894.png)

**nodejs 清空 npm 缓存**

```
npm cache clean -f
```

**查看npm使用的镜像地址**

```
npm config get registry
```

**修改源地址为淘宝 npm 镜像**

```
npm config set registry http://registry.npm.taobao.org/
```

**修改源地址为官方源**

```
npm config set registry https://registry.npmjs.org/
```

**创建vue**

```
vue create 项目名
```

## 修改node.js默认的npm安装目录

![image-20211015212025416](https://cdn.jsdelivr.net/gh/xpnobug/CDN/img/hpp_upload/image-20211015212025416.png)

**设置全局模块的安装路径到node\_gobal文件夹，缓存到node\_cache文件夹：**

```
npm config set prefix "D:\Program Files\nodejs\node_global"

npm config set cache "D:\Program Files\nodejs\node_cache"
```

**配置环境变量**

![image-20211015211152965](https://cdn.jsdelivr.net/gh/xpnobug/CDN/img/hpp_upload/image-20211015211152965.png)
