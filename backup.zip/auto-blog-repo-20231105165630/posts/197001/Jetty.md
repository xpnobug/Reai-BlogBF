---
---
title: Jetty 快速入门
categories: 
  - 编程
  - Java
  - 服务器
tags: 
  - Java
  - JavaWeb
  - 服务器
  - Jetty
abbrlink: 9709eee9
date: 2022-02-17 22:34:30
permalink: /pages/9ecdc1/
---

# Jetty 快速入门

## Jetty 简介

**jetty 是什么？**

jetty 是轻量级的 web 服务器和 servlet 引擎。

它的最大特点是：可以很方便的作为**嵌入式服务器**。

它是 eclipse 的一个开源项目。不用怀疑，就是你常用的那个 eclipse。

它是使用 Java 开发的，所以天然对 Java 支持良好。

[官方网址](http://www.eclipse.org/jetty/index.html)

[github 源码地址](https://github.com/eclipse/jetty.project)

**什么是嵌入式服务器？**

以 jetty 来说明，就是只要引入 jetty 的 jar 包，可以通过直接调用其 API 的方式来启动 web 服务。

用过 Tomcat、Resin 等服务器的朋友想必不会陌生那一套安装、配置、部署的流程吧，还是挺繁琐的。使用 jetty，就不需要这些过程了。

jetty 非常适用于项目的开发、测试，因为非常快捷。如果想用于生产环境，则需要谨慎考虑，它不一定能像成熟的 Tomcat、Resin 等服务器一样支持企业级 Java EE 的需要。

## Jetty 的使用

我觉得嵌入式启动方式的一个好处在于：可以直接运行项目，无需每次部署都得再配置服务器。

jetty 的嵌入式启动使用有两种方式：

API 方式

maven 插件方式

### API 方式

添加 maven 依赖

```xml
<dependency>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>jetty-webapp</artifactId>
  <version>9.3.2.v20150730</version>
  <scope>test</scope>
</dependency>
<dependency>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>jetty-annotations</artifactId>
  <version>9.3.2.v20150730</version>
  <scope>test</scope>
</dependency>
<dependency>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>apache-jsp</artifactId>
  <version>9.3.2.v20150730</version>
  <scope>test</scope>
</dependency>
<dependency>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>apache-jstl</artifactId>
  <version>9.3.2.v20150730</version>
  <scope>test</scope>
</dependency>
```

官方的启动代码

```java
public class SplitFileServer
{
    public static void main( String[] args ) throws Exception
    {
        // 创建Server对象，并绑定端口
        Server server = new Server();
        ServerConnector connector = new ServerConnector(server);
        connector.setPort(8090);
        server.setConnectors(new Connector[] { connector });

        // 创建上下文句柄，绑定上下文路径。这样启动后的url就会是:http://host:port/context
        ResourceHandler rh0 = new ResourceHandler();
        ContextHandler context0 = new ContextHandler();
        context0.setContextPath("/");

        // 绑定测试资源目录（在本例的配置目录dir0的路径是src/test/resources/dir0）
        File dir0 = MavenTestingUtils.getTestResourceDir("dir0");
        context0.setBaseResource(Resource.newResource(dir0));
        context0.setHandler(rh0);

        // 和上面的例子一样
        ResourceHandler rh1 = new ResourceHandler();
        ContextHandler context1 = new ContextHandler();
        context1.setContextPath("/");
        File dir1 = MavenTestingUtils.getTestResourceDir("dir1");
        context1.setBaseResource(Resource.newResource(dir1));
        context1.setHandler(rh1);

        // 绑定两个资源句柄
        ContextHandlerCollection contexts = new ContextHandlerCollection();
        contexts.setHandlers(new Handler[] { context0, context1 });
        server.setHandler(contexts);

        // 启动
        server.start();

        // 打印dump时的信息
        System.out.println(server.dump());

        // join当前线程
        server.join();
    }
}
```

直接运行 Main 方法，就可以启动 web 服务。

**_注：以上代码在 eclipse 中运行没有问题，如果想在 Intellij 中运行还需要为它指定配置文件。_**

如果想了解在 Eclipse 和 Intellij 都能运行的通用方法可以参考我的 github 代码示例。

我的实现也是参考 springside 的方式。

代码行数有点多，不在这里贴代码了。

[完整参考代码](https://github.com/dunwu/spring-notes)

### Maven 插件方式

如果你熟悉 maven，那么实在太简单了

**_注： Maven 版本必须在 3.3 及以上版本。_**

(1) 添加 maven 插件

```xml
<plugin>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>jetty-maven-plugin</artifactId>
  <version>9.3.12.v20160915</version>
</plugin>
```

(2) 执行 maven 命令：

```
mvn jetty:run
```

讲真，就是这么简单。jetty 默认会为你创建一个 web 服务，地址为 127.0.0.1:8080。

当然，你也可以在插件中配置你的 webapp 环境

```xml
<plugin>
  <groupId>org.eclipse.jetty</groupId>
  <artifactId>jetty-maven-plugin</artifactId>
  <version>9.3.12.v20160915</version>

  <configuration>
 <webAppSourceDirectory>${project.basedir}/src/staticfiles</webAppSourceDirectory>

    <!-- 配置webapp -->
 <webApp>
   <contextPath>/</contextPath>
   <descriptor>${project.basedir}/src/over/here/web.xml</descriptor>
   <jettyEnvXml>${project.basedir}/src/over/here/jetty-env.xml</jettyEnvXml>
 </webApp>

    <!-- 配置classes -->
 <classesDirectory>${project.basedir}/somewhere/else</classesDirectory>
 <scanClassesPattern>
   <excludes>
  <exclude>**/Foo.class</exclude>
   </excludes>
 </scanClassesPattern>
 <scanTargets>
   <scanTarget>src/mydir</scanTarget>
   <scanTarget>src/myfile.txt</scanTarget>
 </scanTargets>

    <!-- 扫描target目录下的资源文件 -->
 <scanTargetPatterns>
   <scanTargetPattern>
 <directory>src/other-resources</directory>
 <includes>
   <include>**/*.xml</include>
   <include>**/*.properties</include>
 </includes>
 <excludes>
   <exclude>**/myspecial.xml</exclude>
   <exclude>**/myspecial.properties</exclude>
 </excludes>
   </scanTargetPattern>
 </scanTargetPatterns>
  </configuration>
</plugin>
```

官方给的 jetty-env.xml 范例

```xml
 <?xml version="1.0"?>
 <!DOCTYPE Configure PUBLIC "-//Mort Bay Consulting//DTD Configure//EN" "http://jetty.mortbay.org/configure.dtd">

 <Configure class="org.eclipse.jetty.webapp.WebAppContext">

   <!-- Add an EnvEntry only valid for this webapp               -->
   <New id="gargle"  class="org.eclipse.jetty.plus.jndi.EnvEntry">
     <Arg>gargle</Arg>
     <Arg type="java.lang.Double">100</Arg>
     <Arg type="boolean">true</Arg>
   </New>

  <!-- Add an override for a global EnvEntry                           -->
   <New id="wiggle"  class="org.eclipse.jetty.plus.jndi.EnvEntry">
     <Arg>wiggle</Arg>
     <Arg type="java.lang.Double">55.0</Arg>
     <Arg type="boolean">true</Arg>
   </New>

   <!-- an XADataSource                                                -->
   <New id="mydatasource99" class="org.eclipse.jetty.plus.jndi.Resource">
     <Arg>jdbc/mydatasource99</Arg>
     <Arg>
       <New class="com.atomikos.jdbc.SimpleDataSourceBean">
         <Set name="xaDataSourceClassName">org.apache.derby.jdbc.EmbeddedXADataSource</Set>
         <Set name="xaDataSourceProperties">databaseName=testdb99;createDatabase=create</Set>
         <Set name="UniqueResourceName">mydatasource99</Set>
       </New>
     </Arg>
   </New>

 </Configure>
```

## Jetty 的架构

### Jetty 架构简介

![img](https://raw.githubusercontent.com/dunwu/images/dev/snap/20201127154145.jpg)

Jetty Server 就是由多个 Connector（连接器）、多个 Handler（处理器），以及一个线程池组成。

跟 Tomcat 一样，Jetty 也有 HTTP 服务器和 Servlet 容器的功能，因此 Jetty 中的 Connector 组件和 Handler 组件分别来实现这两个功能，而这两个组件工作时所需要的线程资源都直接从一个全局线程池 ThreadPool 中获取。

Jetty Server 可以有多个 Connector 在不同的端口上监听客户请求，而对于请求处理的 Handler 组件，也可以根据具体场景使用不同的 Handler。这样的设计提高了 Jetty 的灵活性，需要支持 Servlet，则可以使用 ServletHandler；需要支持 Session，则再增加一个 SessionHandler。也就是说我们可以不使用 Servlet 或者 Session，只要不配置这个 Handler 就行了。

为了启动和协调上面的核心组件工作，Jetty 提供了一个 Server 类来做这个事情，它负责创建并初始化 Connector、Handler、ThreadPool 组件，然后调用 start 方法启动它们。

### Jetty 和 Tomcat 架构区别

对比一下 Tomcat 的整体架构图，你会发现 Tomcat 在整体上跟 Jetty 很相似，它们的第一个区别是 Jetty 中没有 Service 的概念，Tomcat 中的 Service 包装了多个连接器和一个容器组件，一个 Tomcat 实例可以配置多个 Service，不同的 Service 通过不同的连接器监听不同的端口；而 Jetty 中 Connector 是被所有 Handler 共享的。

第二个区别是，在 Tomcat 中每个连接器都有自己的线程池，而在 Jetty 中所有的 Connector 共享一个全局的线程池。

### Connector 组件

跟 Tomcat 一样，Connector 的主要功能是对 I/O 模型和应用层协议的封装。I/O 模型方面，最新的 Jetty 9 版本只支持 NIO，因此 Jetty 的 Connector 设计有明显的 Java NIO 通信模型的痕迹。至于应用层协议方面，跟 Tomcat 的 Processor 一样，Jetty 抽象出了 Connection 组件来封装应用层协议的差异。

服务端在 NIO 通信上主要完成了三件事情：**监听连接、I/O 事件查询以及数据读写**。因此 Jetty 设计了**Acceptor、SelectorManager 和 Connection 来分别做这三件事情**

#### Acceptor

**Acceptor 用于接受请求**。跟 Tomcat 一样，Jetty 也有独立的 Acceptor 线程组用于处理连接请求。在 `Connector` 的实现类 `ServerConnector` 中，有一个 `_acceptors` 的数组，在 Connector 启动的时候, 会根据 `_acceptors` 数组的长度创建对应数量的 Acceptor，而 Acceptor 的个数可以配置。

```java
for (int i = 0; i < _acceptors.length; i++)
{
  Acceptor a = new Acceptor(i);
  getExecutor().execute(a);
}
```

`Acceptor` 是 `ServerConnector` 中的一个内部类，同时也是一个 `Runnable`，`Acceptor` 线程是通过 `getExecutor()` 得到的线程池来执行的，前面提到这是一个全局的线程池。

`Acceptor` 通过阻塞的方式来接受连接，这一点跟 Tomcat 也是一样的。

```java
public void accept(int acceptorID) throws IOException
{
  ServerSocketChannel serverChannel = _acceptChannel;
  if (serverChannel != null && serverChannel.isOpen())
  {
    // 这里是阻塞的
    SocketChannel channel = serverChannel.accept();
    // 执行到这里时说明有请求进来了
    accepted(channel);
  }
}
```

接受连接成功后会调用 `accepted()` 函数，`accepted()` 函数中会将 `SocketChannel` 设置为非阻塞模式，然后交给 `Selector` 去处理，因此这也就到了 `Selector` 的地界了。

```java
private void accepted(SocketChannel channel) throws IOException
{
    channel.configureBlocking(false);
    Socket socket = channel.socket();
    configure(socket);
    // _manager 是 SelectorManager 实例，里面管理了所有的 Selector 实例
    _manager.accept(channel);
}
```

**SelectorManager**

**Jetty 的 `Selector` 由 `SelectorManager` 类管理**，而被管理的 `Selector` 叫作 `ManagedSelector`。`SelectorManager` 内部有一个 `ManagedSelector` 数组，真正干活的是 `ManagedSelector`。咱们接着上面分析，看看在 `SelectorManager` 在 `accept` 方法里做了什么。

```java
public void accept(SelectableChannel channel, Object attachment)
{
  // 选择一个 ManagedSelector 来处理 Channel
  final ManagedSelector selector = chooseSelector();
  // 提交一个任务 Accept 给 ManagedSelector
  selector.submit(selector.new Accept(channel, attachment));
}
```

SelectorManager 从本身的 Selector 数组中选择一个 Selector 来处理这个 Channel，并创建一个任务 Accept 交给 ManagedSelector，ManagedSelector 在处理这个任务主要做了两步：

第一步，调用 Selector 的 register 方法把 Channel 注册到 Selector 上，拿到一个 SelectionKey。

```
 _key = _channel.register(selector, SelectionKey.OP_ACCEPT, this);
```

第二步，创建一个 EndPoint 和 Connection，并跟这个 SelectionKey（Channel）绑在一起：

```java
private void createEndPoint(SelectableChannel channel, SelectionKey selectionKey) throws IOException
{
    //1. 创建 Endpoint
    EndPoint endPoint = _selectorManager.newEndPoint(channel, this, selectionKey);

    //2. 创建 Connection
    Connection connection = _selectorManager.newConnection(channel, endPoint, selectionKey.attachment());

    //3. 把 Endpoint、Connection 和 SelectionKey 绑在一起
    endPoint.setConnection(connection);
    selectionKey.attach(endPoint);

}
```

这里需要你特别注意的是，ManagedSelector 并没有直接调用 EndPoint 的方法去处理数据，而是通过调用 EndPoint 的方法**返回一个 Runnable，然后把这个 Runnable 扔给线程池执行**，所以你能猜到，这个 Runnable 才会去真正读数据和处理请求。

**Connection**

这个 Runnable 是 EndPoint 的一个内部类，它会调用 Connection 的回调方法来处理请求。Jetty 的 Connection 组件类比就是 Tomcat 的 Processor，负责具体协议的解析，得到 Request 对象，并调用 Handler 容器进行处理。下面我简单介绍一下它的具体实现类 HttpConnection 对请求和响应的处理过程。

**请求处理**：HttpConnection 并不会主动向 EndPoint 读取数据，而是向在 EndPoint 中注册一堆回调方法：

```
getEndPoint().fillInterested(_readCallback);
```

这段代码就是告诉 EndPoint，数据到了你就调我这些回调方法 \_readCallback 吧，有点异步 I/O 的感觉，也就是说 Jetty 在应用层面模拟了异步 I/O 模型。

而在回调方法 \_readCallback 里，会调用 EndPoint 的接口去读数据，读完后让 HTTP 解析器去解析字节流，HTTP 解析器会将解析后的数据，包括请求行、请求头相关信息存到 Request 对象里。

**响应处理**：Connection 调用 Handler 进行业务处理，Handler 会通过 Response 对象来操作响应流，向流里面写入数据，HttpConnection 再通过 EndPoint 把数据写到 Channel，这样一次响应就完成了。

到此你应该了解了 Connector 的工作原理，下面我画张图再来回顾一下 Connector 的工作流程。

![img](https://raw.githubusercontent.com/dunwu/images/dev/snap/20201118175805.jpg)

1. Acceptor 监听连接请求，当有连接请求到达时就接受连接，一个连接对应一个 Channel，Acceptor 将 Channel 交给 ManagedSelector 来处理。

2. ManagedSelector 把 Channel 注册到 Selector 上，并创建一个 EndPoint 和 Connection 跟这个 Channel 绑定，接着就不断地检测 I/O 事件。

3. I/O 事件到了就调用 EndPoint 的方法拿到一个 Runnable，并扔给线程池执行。

4. 线程池中调度某个线程执行 Runnable。

5. Runnable 执行时，调用回调函数，这个回调函数是 Connection 注册到 EndPoint 中的。

6. 回调函数内部实现，其实就是调用 EndPoint 的接口方法来读数据。

7. Connection 解析读到的数据，生成请求对象并交给 Handler 组件去处理。

### Handler 组件

Jetty 的 Handler 设计是它的一大特色，Jetty 本质就是一个 Handler 管理器，Jetty 本身就提供了一些默认 Handler 来实现 Servlet 容器的功能，你也可以定义自己的 Handler 来添加到 Jetty 中，这体现了“**微内核 + 插件**”的设计思想。

**Handler 就是一个接口，它有一堆实现类**，Jetty 的 Connector 组件调用这些接口来处理 Servlet 请求。

```java
public interface Handler extends LifeCycle, Destroyable
{
    // 处理请求的方法
    public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException;

    // 每个 Handler 都关联一个 Server 组件，被 Server 管理
    public void setServer(Server server);
    public Server getServer();

    // 销毁方法相关的资源
    public void destroy();
}
```

方法说明：

- `Handler` 的 `handle` 方法跟 Tomcat 容器组件的 service 方法一样，它有 `ServletRequest` 和 `ServeletResponse` 两个参数。
- 因为任何一个 `Handler` 都需要关联一个 `Server` 组件，`Handler` 需要被 `Server` 组件来管理。`Handler` 通过 `setServer` 和 `getServer` 方法绑定 `Server`。
- `Handler` 会加载一些资源到内存，因此通过设置 `destroy` 方法来销毁。

#### Handler 继承关系

Handler 只是一个接口，完成具体功能的还是它的子类。那么 Handler 有哪些子类呢？它们的继承关系又是怎样的？这些子类是如何实现 Servlet 容器功能的呢？

![img](https://raw.githubusercontent.com/dunwu/images/dev/snap/20201118181025.png)

在 AbstractHandler 之下有 AbstractHandlerContainer，为什么需要这个类呢？这其实是个过渡，为了实现链式调用，一个 Handler 内部必然要有其他 Handler 的引用，所以这个类的名字里才有 Container，意思就是这样的 Handler 里包含了其他 Handler 的引用。

HandlerWrapper 和 HandlerCollection 都是 Handler，但是这些 Handler 里还包括其他 Handler 的引用。不同的是，HandlerWrapper 只包含一个其他 Handler 的引用，而 HandlerCollection 中有一个 Handler 数组的引用。

HandlerWrapper 有两个子类：Server 和 ScopedHandler。

- Server 比较好理解，它本身是 Handler 模块的入口，必然要将请求传递给其他 Handler 来处理，为了触发其他 Handler 的调用，所以它是一个 HandlerWrapper。
- ScopedHandler 也是一个比较重要的 Handler，实现了“具有上下文信息”的责任链调用。为什么我要强调“具有上下文信息”呢？那是因为 Servlet 规范规定 Servlet 在执行过程中是有上下文的。那么这些 Handler 在执行过程中如何访问这个上下文呢？这个上下文又存在什么地方呢？答案就是通过 ScopedHandler 来实现的。

HandlerCollection 其实维护了一个 Handler 数组。这是为了同时支持多个 Web 应用，如果每个 Web 应用有一个 Handler 入口，那么多个 Web 应用的 Handler 就成了一个数组，比如 Server 中就有一个 HandlerCollection，Server 会根据用户请求的 URL 从数组中选取相应的 Handler 来处理，就是选择特定的 Web 应用来处理请求。

Handler 可以分成三种类型：

- 第一种是**协调 Handler**，这种 Handler 负责将请求路由到一组 Handler 中去，比如 HandlerCollection，它内部持有一个 Handler 数组，当请求到来时，它负责将请求转发到数组中的某一个 Handler。
- 第二种是**过滤器 Handler**，这种 Handler 自己会处理请求，处理完了后再把请求转发到下一个 Handler，比如图上的 HandlerWrapper，它内部持有下一个 Handler 的引用。需要注意的是，所有继承了 HandlerWrapper 的 Handler 都具有了过滤器 Handler 的特征，比如 ContextHandler、SessionHandler 和 WebAppContext 等。
- 第三种是**内容 Handler**，说白了就是这些 Handler 会真正调用 Servlet 来处理请求，生成响应的内容，比如 ServletHandler。如果浏览器请求的是一个静态资源，也有相应的 ResourceHandler 来处理这个请求，返回静态页面。

#### 实现 Servlet 规范

ServletHandler、ContextHandler 以及 WebAppContext 等，它们实现了 Servlet 规范。

Servlet 规范中有 Context、Servlet、Filter、Listener 和 Session 等，Jetty 要支持 Servlet 规范，就需要有相应的 Handler 来分别实现这些功能。因此，Jetty 设计了 3 个组件：ContextHandler、ServletHandler 和 SessionHandler 来实现 Servle 规范中规定的功能，而**WebAppContext 本身就是一个 ContextHandler**，另外它还负责管理 ServletHandler 和 SessionHandler。

ContextHandler 会创建并初始化 Servlet 规范里的 ServletContext 对象，同时 ContextHandler 还包含了一组能够让你的 Web 应用运行起来的 Handler，可以这样理解，Context 本身也是一种 Handler，它里面包含了其他的 Handler，这些 Handler 能处理某个特定 URL 下的请求。比如，ContextHandler 包含了一个或者多个 ServletHandler。

ServletHandler 实现了 Servlet 规范中的 Servlet、Filter 和 Listener 的功能。ServletHandler 依赖 FilterHolder、ServletHolder、ServletMapping、FilterMapping 这四大组件。FilterHolder 和 ServletHolder 分别是 Filter 和 Servlet 的包装类，每一个 Servlet 与路径的映射会被封装成 ServletMapping，而 Filter 与拦截 URL 的映射会被封装成 FilterMapping。

SessionHandler 用来管理 Session。除此之外 WebAppContext 还有一些通用功能的 Handler，比如 SecurityHandler 和 GzipHandler，同样从名字可以知道这些 Handler 的功能分别是安全控制和压缩 / 解压缩。

WebAppContext 会将这些 Handler 构建成一个执行链，通过这个链会最终调用到我们的业务 Servlet。

## Jetty 的线程策略

### 传统 Selector 编程模型

常规的 NIO 编程思路是，将 I/O 事件的侦测和请求的处理分别用不同的线程处理。具体过程是：

启动一个线程，在一个死循环里不断地调用 select 方法，检测 Channel 的 I/O 状态，一旦 I/O 事件达到，比如数据就绪，就把该 I/O 事件以及一些数据包装成一个 Runnable，将 Runnable 放到新线程中去处理。

在这个过程中按照职责划分，有两个线程在干活，一个是 I/O 事件检测线程，另一个是 I/O 事件处理线程。这样的好处是它们互不干扰和阻塞对方。

### Jetty 的 Selector 编程模型

将 I/O 事件检测和业务处理这两种工作分开的思路也有缺点：当 Selector 检测读就绪事件时，数据已经被拷贝到内核中的缓存了，同时 CPU 的缓存中也有这些数据了，我们知道 CPU 本身的缓存比内存快多了，这时当应用程序去读取这些数据时，如果用另一个线程去读，很有可能这个读线程使用另一个 CPU 核，而不是之前那个检测数据就绪的 CPU 核，这样 CPU 缓存中的数据就用不上了，并且线程切换也需要开销。

因此 Jetty 的 Connector 做了一个大胆尝试，那就是**把 I/O 事件的生产和消费放到同一个线程来处理**，如果这两个任务由同一个线程来执行，如果执行过程中线程不阻塞，操作系统会用同一个 CPU 核来执行这两个任务，这样就能利用 CPU 缓存了。

#### ManagedSelector

ManagedSelector 的本质就是一个 Selector，负责 I/O 事件的检测和分发。为了方便使用，Jetty 在 Java 原生的 Selector 上做了一些扩展，就变成了 ManagedSelector，我们先来看看它有哪些成员变量：

```java
public class ManagedSelector extends ContainerLifeCycle implements Dumpable
{
    // 原子变量，表明当前的 ManagedSelector 是否已经启动
    private final AtomicBoolean _started = new AtomicBoolean(false);

    // 表明是否阻塞在 select 调用上
    private boolean _selecting = false;

    // 管理器的引用，SelectorManager 管理若干 ManagedSelector 的生命周期
    private final SelectorManager _selectorManager;

    //ManagedSelector 不止一个，为它们每人分配一个 id
    private final int _id;

    // 关键的执行策略，生产者和消费者是否在同一个线程处理由它决定
    private final ExecutionStrategy _strategy;

    //Java 原生的 Selector
    private Selector _selector;

    //"Selector 更新任务 " 队列
    private Deque<SelectorUpdate> _updates = new ArrayDeque<>();
    private Deque<SelectorUpdate> _updateable = new ArrayDeque<>();

    ...
}
```

这些成员变量中其他的都好理解，就是“Selector 更新任务”队列`_updates`和执行策略`_strategy`可能不是很直观。

#### SelectorUpdate 接口

为什么需要一个“Selector 更新任务”队列呢，对于 Selector 的用户来说，我们对 Selector 的操作无非是将 Channel 注册到 Selector 或者告诉 Selector 我对什么 I/O 事件感兴趣，那么这些操作其实就是对 Selector 状态的更新，Jetty 把这些操作抽象成 SelectorUpdate 接口。

```
/**
 * A selector update to be done when the selector has been woken.
 */
public interface SelectorUpdate
{
    void update(Selector selector);
}
```

这意味着如果你不能直接操作 ManageSelector 中的 Selector，而是需要向 ManagedSelector 提交一个任务类，这个类需要实现 SelectorUpdate 接口 update 方法，在 update 方法里定义你想要对 ManagedSelector 做的操作。

比如 Connector 中 Endpoint 组件对读就绪事件感兴趣，它就向 ManagedSelector 提交了一个内部任务类 ManagedSelector.SelectorUpdate：

```
_selector.submit(_updateKeyAction);
```

这个`_updateKeyAction`就是一个 SelectorUpdate 实例，它的 update 方法实现如下：

```
private final ManagedSelector.SelectorUpdate _updateKeyAction = new ManagedSelector.SelectorUpdate()
{
    @Override
    public void update(Selector selector)
    {
        // 这里的 updateKey 其实就是调用了 SelectionKey.interestOps(OP_READ);
        updateKey();
    }
};
```

我们看到在 update 方法里，调用了 SelectionKey 类的 interestOps 方法，传入的参数是`OP_READ`，意思是现在我对这个 Channel 上的读就绪事件感兴趣了。

那谁来负责执行这些 update 方法呢，答案是 ManagedSelector 自己，它在一个死循环里拉取这些 SelectorUpdate 任务类逐个执行。

#### Selectable 接口

那 I/O 事件到达时，ManagedSelector 怎么知道应该调哪个函数来处理呢？其实也是通过一个任务类接口，这个接口就是 Selectable，它返回一个 Runnable，这个 Runnable 其实就是 I/O 事件就绪时相应的处理逻辑。

```
public interface Selectable
{
    // 当某一个 Channel 的 I/O 事件就绪后，ManagedSelector 会调用的回调函数
    Runnable onSelected();

    // 当所有事件处理完了之后 ManagedSelector 会调的回调函数，我们先忽略。
    void updateKey();
}
```

ManagedSelector 在检测到某个 Channel 上的 I/O 事件就绪时，也就是说这个 Channel 被选中了，ManagedSelector 调用这个 Channel 所绑定的附件类的 onSelected 方法来拿到一个 Runnable。

这句话有点绕，其实就是 ManagedSelector 的使用者，比如 Endpoint 组件在向 ManagedSelector 注册读就绪事件时，同时也要告诉 ManagedSelector 在事件就绪时执行什么任务，具体来说就是传入一个附件类，这个附件类需要实现 Selectable 接口。ManagedSelector 通过调用这个 onSelected 拿到一个 Runnable，然后把 Runnable 扔给线程池去执行。

那 Endpoint 的 onSelected 是如何实现的呢？

```
@Override
public Runnable onSelected()
{
    int readyOps = _key.readyOps();

    boolean fillable = (readyOps & SelectionKey.OP_READ) != 0;
    boolean flushable = (readyOps & SelectionKey.OP_WRITE) != 0;

    // return task to complete the job
    Runnable task= fillable
            ? (flushable
                    ? _runCompleteWriteFillable
                    : _runFillable)
            : (flushable
                    ? _runCompleteWrite
                    : null);

    return task;
}
```

上面的代码逻辑很简单，就是读事件到了就读，写事件到了就写。

#### ExecutionStrategy

铺垫了这么多，终于要上主菜了。前面我主要介绍了 ManagedSelector 的使用者如何跟 ManagedSelector 交互，也就是如何注册 Channel 以及 I/O 事件，提供什么样的处理类来处理 I/O 事件，接下来我们来看看 ManagedSelector 是如何统一管理和维护用户注册的 Channel 集合。再回到今天开始的讨论，ManagedSelector 将 I/O 事件的生产和消费看作是生产者消费者模式，为了充分利用 CPU 缓存，生产和消费尽量放到同一个线程处理，那这是如何实现的呢？Jetty 定义了 ExecutionStrategy 接口：

```
public interface ExecutionStrategy
{
    // 只在 HTTP2 中用到，简单起见，我们先忽略这个方法。
    public void dispatch();

    // 实现具体执行策略，任务生产出来后可能由当前线程执行，也可能由新线程来执行
    public void produce();

    // 任务的生产委托给 Producer 内部接口，
    public interface Producer
    {
        // 生产一个 Runnable(任务)
        Runnable produce();
    }
}
```

我们看到 ExecutionStrategy 接口比较简单，它将具体任务的生产委托内部接口 Producer，而在自己的 produce 方法里来实现具体执行逻辑，**也就是生产出来的任务要么由当前线程执行，要么放到新线程中执行**。Jetty 提供了一些具体策略实现类：ProduceConsume、ProduceExecuteConsume、ExecuteProduceConsume 和 EatWhatYouKill。它们的区别是：

- ProduceConsume：任务生产者自己依次生产和执行任务，对应到 NIO 通信模型就是用一个线程来侦测和处理一个 ManagedSelector 上所有的 I/O 事件，后面的 I/O 事件要等待前面的 I/O 事件处理完，效率明显不高。通过图来理解，图中绿色表示生产一个任务，蓝色表示执行这个任务。

![img](data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAvUAAAA1CAYAAADBNRQQAAAUuUlEQVR42u2dCXgV5dXHyUIWQAJJQEF2P7e6VgG1qIUY9iqI8hFQaB/7tdbuaqmtC1pEUZa6VEVFK2KlSkEp2ycoi6IIQsUgAgkEEnYIYctCCLnz9py5Z8Kb4d4scO/NzJ3/eZ7/c+fOzL25mXPueX9z5sx7GzWCwWAwGAwGg8FgMFjUWgwpVlOcpngHKq4Oive4Ah2PuAA+dvJnj4dvoTOIb+QvKFz+ig2yjFhzrr8sxQD1YF4CeuvLnUBKJCWRkh2qJJsSteVkqJoStWOky+nHq0kNvodfoUC5INH2HPkLCnUuTQySSxFrzvQX80xjYRuAPcwzQG/BPH8RmpFSSC1JqaQ0UrqDlCZKFbXUlKptd9rnbohjZB0X9mdzES+3EDnZv2kBfAnfQsFyQAvbYyryFxQif+kx1kLLoym2eEOsOctf7J9zNMAH2MOi3qwKfYJURlOe29xfOV2TN5K+668mZvdTz37dRz39VR81YlolZNPwv1eQTqisN46rYa8XK/JvG7f4dtL6fmrCur5q/Jre8CVUS3yXqWGvHeP4bo/8BUUo1tog1twj8ldTG9jDYFEL9fFyJstntee6JVFN2uCHPk5SY1fcgoEnyECU9Wa5yppaqoZOOcyJ7SK3+HZidl/1zNre6skvMuFLqMb45hPWO18p4vi+DPkLilCsXYRYcxXUt5TCZWMpZMJgUQv1CdJy04rUyS2JiisPz6ztY0LfY5/0xMATbCDiKj1Vlu54aT8ntq6uGITW+6tK477srR5f2gu+hGqI7zL1v68eUXe8uIfjuwfyFxShWOuKWHMV1J8rbVNJAvUxaMOBRaPFySUprtK3JV3iikRlXk70Vx6e+DRD/WnBzRh4ahiIuEo/5IVdnNh+6J5BqLdZVXr4IwAPFCy+T5hXobhyevtzBRzf/ZC/oAjFWi/EmqugvoNU65OlOwFQD4taqE+SYOegv9ItiWrCN33VU6t6qzFLMtToORgUg0K92XpziAaifE5s/d0B9f5e+ieWZ6iH5sG3UHDQGja1RN358gE1eHIex/cQ5C8oQrHWH7HmKqjvIjfSWi04gHpYVJrVT893i3ciXeuGRGX1CHJ7Bl9OfHDWjRh4aqwuFdJAtI0T2yC3VJaeWp1ptt4AeKBgsnqcubVs0KQtHN8jkL+gCMXaYMSaq6D+QlJruWEWUA+LeqhPkzPZbu5KVJnq0cU91QMze2DgiZJKpr2y9IcPboIvoVpAa5+6bUIOx/dI5C8oQrF2B2LNVVB/sUB9M0A9zAtQz5elLiB1d1OienJlpnpkUU91//sYFGuD+kGTtnJiG+oqqOfK0mxUMaFaQOtvewm0NnN8j0L+giIUa0MRa66C+kvkZllAPQxQj0QFqAfUQ4B65C/EGqAeUA+DAeqRqAD1gHoIUI/8BahHrAHqYTBAPRIVoB6CAPUQoB6xBqiHwQD1gHpAPQSoR/6CAPWAekA9DFCPRAWoB9RDgHrkL0A9Yg1QD4MB6pGoAPWAeghQj/wFqEesAephMGdC/e6yTcpuJ3ylanfpJrV0/2sBXzNn51i1q3Sj+sf237kuUeUcME77fw3DUEWlSq3KN9SDc3ynveanMyrVd/sMNX2N4Tqor49/n9/8I/V54TuqsHy7Kq8sNX08d9fTgPowxda4xf64KjlhqJ2HDfXhep8aNR1QH674fiV3mPr2yCJ1rKJQHa8sVttK1qoZ2+/3HGjVN07fXGWo/EOGOn7SUNvp8bUvfZ6E+jMZK1n/3vWkmUuX7X/dkbF2JmMi6+fvVapv9xpq7U4DUB8Ji4mJKYiPj1c16Cva7be8TI99nPCZY2Nj/yKfp6ttUzKtX06Po8Hz4YH6bSVr1Iajn5jKOfY5QV2JuX7VwZnVoI8TVOnJw+a2fxX82bVQ/5+dSi3bapj6LM9QBYf96w9RImOIt/bnhLZ+jz/RLdrsXqivi3+/PbLYXFdQkq3WHZ6viiuKzOdzdz0FqA9xbI3/xGcOnPuOKbVwk6Fy5bUrthmA+jDEN+eu/ce3mus20/bc4pWq0qggKDuupuXd60mor0uc/vNr/7q8g4ZanGOow2X+XPjWV4Znob4uudTSq1tGqLKTR8ztXx+a62ior+uYaGllvn87xwSgPjKA/HJcXNxMFgH+BgH5NdY62v60C6CenXcFfd6PeD3/T+E4/+E/HURxDlSsBHcTUivS/5Cu++ums0tU9orVW3k/M6GDKxE8IC6lKgMPgrq5Geofnl+9+nAXaUuhf9ukZT71m1mVqrSiegXDzVBfm3+t5wz01j5/3/Z/tM5nVqIA9aGLLV63rchQJ32G+uVM/z53v31qn1/9C1Af6vjmK05sa4o+qNrnswPTzHWfF073JNTXFqc/fqdSlVN1fs9RVXUF6fcf+MztXLn3KtTXFmv6Nj55PFpxwBVQX5e8Zen5z3zqBMXGkePhgfrhb52kcbCC/XUp6TzSOaQEh3NZIIXtBOQxhmKC43ts6x0N9XQykqtfXQgD1MdoUG85p7GmBAeKP1eSnLnyGeyFFtSfCdgHS1Qsq1L7+taR6sOdf6mqTljrownqWUty/dte/sKnfvF+pVq6xTC1eb8RdVBv9+/CPZPM5SX7Xq22T8nJQ+aVGUB96GKLYYlt477q8bRgo3+fx//fB6gPcXyvLHzXrKj+M//Bqu2zd4wxt688OANQHyBO/zjXZ7aGzfnWVw30uNix8wigPlisWesW7J5oFsL46rYbod4eD9Y6HhuPlRvq3bWGWZwINdSbQH8K6r9HakNqId0JTuayxtJFEa+BftiuLNQI9bR+FGkOQXQRPS6k9bdqoP066X1azKTtObT/57Ipg5ZX0Lqj3MoT4L2H8HraXsL7yPteqm1Pp/edTtsO8t+l5ddIE22V+kdp3V/ptR+GAep1oI8XhyQKMCdLJbypQ9VMgrwt6WLSDZM3+qG+vmAfLFFN2ZKlfEalWYF4MWdwtW3bS7+Oykr9Qf9VVPXQ3Orbpqz0RR3U2/3LsLOCKpbT8u6r2mfq1lHma/eW5QLqQxhbfCmb2xomL6++n3Xy+OtZqNSHM3+xGL52lK0399FB3+uV+mA5kMUno++t879WB32vQ32gWOP44vs2+GSSr3i6tVIfKB7W7PDfW8FXF0MN9TrQs+/IX5eT2pPSpFrvZC5LFn5M1AA/bGBfI9QTVB+WdpwxtHyAQVvOPhoxxNPzPaRiWv6M9hvLlX167qP3W0TLv6B1MwTGH5D3vZ63kzbS8oO8npYL+aSgqimceuQF1N/hXnmuypPKg/TUDwgT1Mdq1Xl2hnKpbuAkYIH9mSQqvhQ9d9d4U4v3vkD9p3nm+q3Fq097TTRAPfcuz/3OZ4p7RfmmILaPc04H92iA+vr41+pB5t5RtsV7XwLUhym2LL0iMZa9R0X9cQoH1NcnvjceXVbVUsfVVK/eKFufOOX2i0qf/3V88+RdHr5Rti6xxrnzYPkOgvzbXAP1dYmHl1f46ATGqDoBCAvUE9DzGJj1xnH215Uu5jI72EcO6rntRavMjxWw/pEF9fJ8jHYT7jfcpy9AbBr3vdO6Q1JF7k/v86o4xHrfafI+fLZ1vfzdf+jdN3zy0ABQHy9nVk1dHDw3ni3UBzKu0HK1NhqhPpBxchoToPUhGqC+Pv6dsmW4yi9dZ+6z6dintG4goD5MsWXdjMhVvkKqilk99oD68MX3wj2TzVlwuK2Mb2KcteNhz89+U1uccivOPII9hjiGutnZ3m2/qS3WFu193vw+v5c/uureJDdAfW3xwPf6cDsWx4H12nBBPfsta2op++v7LuaypAaDeoZmDc6Hyr4/sUF9C9mlKcG3wVV4guy/WaJ9Vsl+18h+7fjv0bYJ9LiA9q+U7Sn0/KeyPNjWU/9mhKFer9LzyUZLUmvp4Wonl306OEjtNHWQm2T5xOmmSev7mWDFYH8miWo13bnPFVnW/N3Pqre333faTT/RBPVjF/mnqmRxsuLpKtm4V5AvM0cb1NfVvzPy7zf7Q3lQ+qpodtAYANSffWzd826lWrfbP3jya++b6Y3jFA6or0/+OtVe9mOz57mg5BtPQn19cqAlbrng2cA4P/CUhl6E+tpijU8WeQrL2TseM8WQz7aleJX53KlQX1s88D0/fHMstw2O+7jSFM/eVUzbeZl77UMD9f4qPY+BwpMXkToJjzmZy9oIP6YKT1r3AFj99Q1zo2wgqOfWG+01raRlZz1B9mS7ZIrFIQzxpGxa9yy9192k+RbUk+6T5b62z/N4A0E9H/zm0rfFN5+erwVOR4epvaij3CR7FUP9xOyzg/r6zNccjT31rFy50/+hedHfUx9Ib2/7pdkHyoMS30SIH58KX2yNeucUHM3K9ven4senwhff31HLTWF5gXkVSl/Pv8nAYF+Xk1cv3Cirx+mL1Gqxg6Y15Ef7lSW2ict8noT62mKNf+OjJnNarNU1Hj7JNWr8v5771BdaqCe/kb+ulWktO2v841Quayv8mCY8mSxt7I6E+qO2OfAPajfMWnYL6Xdc9aZtn3KfvrS1WO87T4P6DIH0cfob0D7LGrBS30wq9a1kCqXzbZVxp+h87aTjglBV6gH1p+705znEvQb1L+UOoZluikygfzPvHvyibJhjq2pWiRU+zx2nhoB66zcY5u+eULXujbyfmCdVxRUHcaNsgDh96mN/3ltVYAR8/SMLAPWBxG03Mwv+VCVrZjGe3pKfu3H2G46H33/oU098VF083SlX6nn53vfCXqlv53AuO0/4saUbKvVHba97RCB7PB903pf2KZUfiOL3+Jgr9Vyhp6eX8d+h5xXyt3pI//wGUhkt38sQz7PcWFNXNkBPfYLcVX2OtBmliXNaO1DpcjbYRs4Q+fj2MHvqAfVnlcDmbvCdNn2XV6CepyxlKyrfSVXNJdWUfXghoD6EscVV+TKaFvBEpaGWbz1dwX7BEVB/5vH9Lv36NQM8V1HXHppj/u7GgePbzdd+QTOUAOoDxylPXcnHjX81lG/mtn5wiHupR06vBNTXQW6d/aamMTEiPfVvlLG/riZ1EWg+1+Fclq4BfRMpase7BeobE2A/Q+tPWCDON8rKP8fWjbbtsrZJG85EWd4p+3Sh56u1fXK4VacBZ79JlDOrpuKU5nJVwYlqIQHUTqYJvcEC+lBNaelFqJ/6pT+B8cDlNaj/Dw04wYxbcgD1oYutMQt9NV7G5t5WQH3o89c86n+2fg2bjX9N1g/0AwH1QXIgV2etqVYt48q9W27oBtSHZ0wMN9Rrs99cIcXL1gLMTuayc6TjI1mb1jIu3D9CFWprLFDZuoZtbbR1neWMS7d0Wd8QpoO9VbHX56p3opLkxCNFji1fmrqegb6+VfpIK1oGRTdBfaQEqIcaAurPRNx2w78C+sLmW5G/6ii+eXL0v33mzd0ujzXH51Kvx5oO9tKJ0E5uPm3mcC6z5qhPsFXoYxvBGgTs9V+VjdfU2CHSP5M1BWdr6xdlnQ70gHpAPQQ5AeqRvzwda4B6F4G9Vhhurk0R6VQui9cYEkDvALB3k+Ll7DBdbpbtXt+2GyQqQD2gHgLUI38B6hFrTgV7mfnmXKnSN3Yhq8UAr2F1sdOgHokKUA+ohwD1yF8QoD5aVAPUw2CAeiQqQD2gHgLUI38B6hFrgHoYDFCPRAWoB9RDgHrkL0A9Yg1QD4MB6pGoAPUQQAtQDwHqEWuAehgMUA+oB9RDgHrkLwhQD6iHwQD1SFSAekA9BKhH/gLUI9YA9TAYoB6JClAPqIcA9RCgHrEGqIfBAPUYFAH1EEALUA8B6hFrgHoYoB5QD6gH1EOAeuQvCFAPqIfBXA/1aaQupG5uSlTjvsxUjy7uqR6YiUGxNqgfPDmPE9sQV0H9kgz1hw9ugi+hmkHrpX0EWjkc3yORv6AIxdodiDVXQf3FpNaAephXoD6V1Il0jbsSVW/1GKq5NUJ91tRSdecrhQT12zixDXID1E/MJqhfnakeX9pLjZ5zM3wJ1QJa++lK1BaO7+HIX1CEYm0QYs1VUH+hQH1TQD0smi2OlERqSepAutINicpezQX4BYP6ChPqh045pG5/Lp8TWz/H+3ajH+rHr+mtnlieoR6aB99C0XMlCvkramKtP2LNVVDfRdqMmwDqYdEO9YmkFFJb6Tu7jtSbNJiURbqbe1UdpJGku+SzDeWBXD7r7aQ7Zf1dst8oj4r/9+FyPG4j9SX1Iv2QdAsPSJp/nXasRkrM8ecaIf9HlmiEx/0KVc8Bw7gNQmKcY7ofaQBXUSX2hyN/QSHwV5b45lYZGzmX9iRlkgaKDzFWOstfQyQf/IB0Oam9FC+TpUMBUA+LSoslJUifWbq04FwuYM9Jq48MlgMdJGvw7itJNUNTpnxma3Af6FENkOPDAH8z6QZSV1F3Ug8ZmKxj5bTPPkDzs64BmgZCno7vfgJYGRLjP5C4vlFOXjNlH+Qv6Gz91Uf8c5OMjVYuvU7iLQNjpeP81UvGvSsb+ScB4Ztkm0sRMw5QD4tmqLf66lMk8DtKxZ6/DNdoIOgUdRNdK5/vatJV8niNrLf26e5RWcfn++LH75EuEvENQ5fZ/NvNof9DV+2xu+1zetm/XpcVE9b3/wopRlwmukpi/1rkLyhEufRqibFLbLn0cs13iDXn+Iv/z0tJnUltpEpvtd7EAf1g0Qz1cVKtbyJgny5fgvZSue/iUHUWdZITkY6y7OTPHOnj00n8eL60V50nj+00/3Z22Oe+wKZA2+BfyPr+8/e+g8SzFdfttXyA/AWFwlcdJb7ayvjYRsulHRBrjvt/O4h/WpFaNPLfIJsoRcxYoB8sWi1Gq9YnSMW+mVym4jNbnhUnzaFK1R5Tbesgv1pKQksRnzaX5RYipx+vdJvStEcISpUYt+K8pS22kb+gUMaZnktTNGGsdKa/UoRnkm1Aj7YbmCfAPk6De/4CJMmXwYlKsn0+J3/Whpbly0RNCQGOodPUBL6D6pELkrRYT0L+gsKUS/Ucmoix0vH+StBabgD0ME+BvQX3FuDrineQ4uqheI8q0LGI1R5jXeTfePgWqkcOQP6CwumvWFsuRay5w18AehgMBoPBYDAYDOYs+y+rVzUaolvqoQAAAABJRU5ErkJggg==)

- ProduceExecuteConsume：任务生产者开启新线程来运行任务，这是典型的 I/O 事件侦测和处理用不同的线程来处理，缺点是不能利用 CPU 缓存，并且线程切换成本高。同样我们通过一张图来理解，图中的棕色表示线程切换。

![img](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAucAAAEHCAYAAAANq+jXAAAw4ElEQVR42u2dCZgU5bnve/aFGRhgANlhUBHEDUFRE5OggqCIAWVRNHn03KMm95rFx+O9yRVPuEZFwMQoKhCXaGLikqMHl4hLcIvBJUYMLiAiiAKyyirgdNd936634KOZHh2mu6e6+/d7nv/T1VXVVd90Vff86uu3qiIRAAAAAAAACD0FksIkKQphkrWRttP2r9v2IAV8/AEAACCMYh5ITLGkRFJqKQthgraVJAltp+2Ntb04QdoLkHQAAAAIm5gXm7yUS1pJqiTVktYhTbW1Udta6aSKttP2Rtqu7a4wYS9JEHQAAACAFpfzQMxVyqt+9f4ILxty03sjvBnvjPCmLzrdu/Gt4Z60vZa20/amxCS91D4D9J4DAABAi1NoYq69iNrr2S5bxGrGu74gTls43LvhjWEqWj1pO21vopy3NkEvidB7DgAAACGScy1LaCvpkm2SOPXNYd4vF5ymojWAttP2Jsp5h4hf6qIHp0XIOQAAAIRBzvVnfe017yipyyZJnLbw9Hjv7ZSXT1HROpG20/Ymynk3OyitsINU5BwAAABaFO0t1F7DNpIukn5ZI4nvjIiXVlz32jDvP18YqqJ1Gm2n7U2U87qI33uuJ4kGpS0AAAAALSrneiJojaSH5MhskkQ9IfGXr57qTX4uLomjaDttb6Kc95UcFPFLW5BzAAAACI2ct5P0lAzMNkm89u+neZOf/baK1ljaTtubKOf9I/4vRirnpcg5AAAAhEnOe0mOzUZJvNqXxHG0nbY3Uc4HSLpG/Ku2IOcAAAAQGjlvL+ktGZR9kniqd/Uz31HRGk/baTtyDgAAAMg5kkjbkXMAAAAA5BzBpe3IOQAAACDnSCJtR84BAAAAkHMEl7Yj5wAAAICcI4m0HTkHAAAAQM4RXNqOnAMAAABy/jXz6Y73vER2Rbd7n25/z/vrZ7MafM2jK6d4n2x/1/v9Rz9qUUlsStt//f6Z3svr7vPW7fzI21m/Pd7+uZ9clxVtv23JeO9fn8/ztuxe531Rv9Vbtu0N7/6PfpIVbXfz35/8v/j7Pv+z2cg5AADkHwUFBSuKi4u9RvKazHa5DsvjsDC0ubCw8BfWnkEJkypk/PPyeGU63qoszH5yftN7zROtZdte9xZtfjaexVteFoHdFh+/YP2D+wiuCtb2LzfFpz204v+EQs6/Ttv/9fnT8XErti30/rnpcW/r7g3x53M/+WWo267v+WdfLI2Pe1+mL9n6ilcf2y0y/IV3z4eXhP59D3LHB+d5O778PD79zY1zD2i9uo9rksh5ASGEEJLipFx0ZxYVFT2oEVFfZEL+ejBOpl+XBXKub8wR0t6ndLz+TWmU80JLUUKKQ5SgTSWSSkmtpC4Vcp7YE3v3h//Di8Vi8R5RFcS/Sm+nSqFLWOT8q9oePFcxD+a5a9m/ybhovLc3zG3X3n3l9Q3/tWeeF9feEx/38rp7Q912d5oeVGzevTZVcn6EpJukxg5Si0P4WSWEEJIdSfS+Qidp5WqVW5HcixLGh1rO5aBiidvbnwY5L3CEvNikt8z+4WsqQppK6zU8SHKI5LgZ7/rikirR0gS9y7OXXuA9svIXe3pJg/FhlfPEtj+5anp8+Lk1d+wzz7YvN8Z/BQhz219Z94d4j/Qfl1+xZ/qfP54cn/7K+vtD3fZg3BOfTosf2OmvLgcq57pv6z6uf4e0/ShJTzs4rQ7x55QQQkj2pNwcsMSR9rRKeqNyLuMvlDwqMrxBHp+U8aMcYZ4teUAGT5Xpi2X+l23SUBl+ScZt1hKZBpY9RsfL9G06jy23nzO9VpZ7r0xbr+uV4VmSaQk95/9Xxt0kr30kDXKeKOZltnGqTHzbWM9c2BK0q9Z6D/tKjldpORBBTyZat38wwYvG6uM9ob9ZfPY+0z7a/mao5Tyx7Sq2L0kv8z0fXrZnnjlLL4y/dvWOJaFue+LrVHo/3vF2fB5X2MPadm2v1snrQYb+WnEgcu6K+fRFp2vbj5H0kXS20q4aQgghpJlu1docsNKR9KIWk3OR401W5jJZhteqMFstZ0RlXJ6vkmyV4Rdlvina0y7Po7K8eTJ8qYy736T6p7bcITpd8q4MX6HjZXidyn2wYq0hN+G+T2vJtZdcsjNJzfnINMp5IOatJF6W5sTpb58el5cDlXMtlZj7yfXxPL36Zqlz/jA+funWV/d7TdjkvCltD+q4tV5aeXr1rVnT9nc3z99TUqS90dnwvuv7vH7nxyLrZzVbzlXMpy0crm0fnMWfVUIIIdmRQNALnXObMifnWk7i9JRPMUE+M5Bzez7ZOdn0La1jtyOKOFoXLuM22lHHCFnOHfJ4pLPce2w5+jP0EFvv792qFj0IyKCcFzr12xV2xJStO9A3VFpUXlRimnvljQDtVdYe5rDLeVPafvsHE73l2/8Zn+e9LS/IuDOypu1PrpoRv2qLluLoyZUPf/yzULd93upfx3vR/7T8yj11/gci53t6zeUA9MZ/xuX8eP5pEEIISXMqraO6qEXkXOXXkexzbd7vJ8h5jc3SSiQ6pr3iIsu3BJF5Fth8A22+bro+mXajPD4h89fb9Dby/GIbPjuh5vzOFpDzUus117+vk6S7nWSptdyHhTCHWtv0sb/9xH+yildz5PxVucKG9iJrHv90qve7jy7b76S+sMr51237/ct/Eq+JVmF8bcOfk/59YWy7mzlLvxev4V6x7a1Qt10PIvTSiX/++Op4VNaVD7YuiD9vqpxPW3i6N/Ufw7TtJ1jdeT8r6zo0pJ9VQggh4U/wf6TOHFDP52tnnc1lVmHRInI+rDE515IW5zUdrBTmbZHlGYmxWtAxKuOShTJuqixrkuTxQM4ll9nw8IT2XIOct4ycN+W62WGvOW8ov1v2g3jtswqjnlDZ0jfy+bptf0dKWdbtXBHv8XfH6/XaVdC/7gFGS7RdryffGF+77cg5IYSQzMh5j2yS8837FGtLTbpzYmjAKZIf6dmuMu0FrWO3PypY7mOOnA812b7WXYDMM78Fy1ra2EmWnU3Qe9mG6hOiaHt6O23ra6VDzS5ryWU5v3XJGLkyy4a4mN/54UWhuMvm1217cH32xz+9cc+43374/Xjv/9bd60Pddi1neXDF/96T4Ko5ellFfd6MspYhEf9a54c4n4mwfVYJIYRkR+rMq9T9umgntDlhK+vAzQ45F35usny9lrHovDLPdrtRkC7jGe051x5zeXq4rkee77Z1nWT15YskO2T4EpVxvSpLcMnEFjwhtI1d/aGjHTl1tg0VlnR22tXVpETf35OCE0KR8/2jl4FUNuxcKT3Rz+2ThZueDHXb/yB3YVUR117oNzY+Gr/e/NovPoq/9m9yBZSw/2LhJsUnhGpvR0/7HHQO4WeVEEJIdiRwq46RvVcA017z8si+V2wJvZyXiCjfION3BUKtJ4TaH6YMlmmfBNOsvGWaDa+0eerk+avOPIu1BKYF5DzZpRTdS+y0DUnc9tTaUZ72ng8Jes1TdSnFXJLzf4gMJkNLXcIuuI9JPXdwV1ZF7w7qi/kZeSXnjVxKsW0IP6uEEEKyI8H/D/dSiuUJJ4OmRc7TRYnVfXZsZFpnZ1xv6+lyqbXxLUFO3YToQG9ElMmkUhLzre1azqJ34bz5/VF59b5zEyJCCCGRzN2EKChlSftNiOCrBb3QEfWiSHhvBx7UyVdaXZTWSg0Obm2O4NL2XJRzV9Cl7UdE/Btw1diXKbefJoQQ0ly3cpN1veXQ8hSZlLS3Xx0GIYm0PdflPIidDNrVfj0qpVcDAAAAkHMEl7Yj5wAAAADIOW1HzpFzAAAAQM4RXNqOnAMAAAAg57QdOUfOAQAAADlHEmk7cg4AAACAnNN22o6cAwAAAHKOJNJ25BwAAADggOX82CyWxHG0nbYj5wAAAJALct5O0ksyMPsk8TTv6me/raJ1Dm2n7U2U88ORcwAAAAijnLeV9JQcnW2S+MsFp3mTfUn8Lm2n7U2U836SzpJq5BwAAADCIudlkjaSbpIB2SSJ0xYO9657bZh3zfx4ecUZtJ22N1HOD5V0klQh5wAAABAmOdef9Q8yWRkkOUUyWjJOcp7kghBlkmSi5FzJKMlwyVDJd6zdIyVjJONpO21PaPtYyQjJNyVHRfxSrlpJpaQEOQcAAIAwyLlKSauIf1JoD0l/yWDJyZLTJKdLzghRRpoYnmptPMHaqwcVx0u+YcI4jLbT9oS268HESZJjJIdIukhqJBWSYuQcAAAAWppCkxKtO9fSlo4Rv/a8r+QIyUATsONClkEmWEfawcRh1matIdYrcBxF22l7A20/OuKfBHpwxD8RVA9ItaSlzA5UC/hKAAAAgJaW86D3vMIEXX/m1x5F7UXXyyv2MZkJS7Q9ddY2bWM3a29XS3c7wKDttD2x7b2s3VrCpVcoqrYD06DXHDkHAACAFqUgsrf3vNQEvcokXa/g0t5kXdMhRKk1uWpn7axx0tbG03ba3lDbtZ16jkUrE/MSO0ClpAUAAABCQWFkbw+6SnqZSYumMsSpsMegrWU2roK20/ZG2l5hbS61/T0Qc3rNAQAAIDQUJEh6IOphj9vWxEfaTtsba3uRs88DAAAAhFLQCcnHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZAEFlsIkKWpmki0rlevIhSR739ke7BcNpYCvLgAAgNwWcxWBYkmJpdRS1syUJqSkgXFleR73vXC3QUkD7xnbIz/3jRLbN1xpR9ABAAByTMoL7B99IGjlkkpJtaV1ClLtpJWTVK4jFxK8P1UW971qnebtUcX2yIp9o8KEvQRBBwAAyE05L7R/9CrlrdbMO9zLRMbP2eZN+O0X3sS7dnkT7/7SO++e+ryOvgfx3LU7/r7o+yPbo5btQRqKSXog6Mg5AABADsl5sfXEac9pu0zJ4Lg7PvcmzNnuTbhzZ1xIkXNfzvX90PdF3x/ZHr3ZHiSJnFeboBfbATYAAADkgJwHveZaxtJO0iVTMjj21s+8cbM2W28tMrhPr/msLfH3R7bHUWwPkkTOa+2AutTpPacHHQAAIMvlvMj+uWsvXCdJXaZkcMzNK71zb98Y762llCKQ810ixzvkfdkk788nKmDfYHuQJHLeRVIT8cvRipFzAACA3JFz/efeRtJV0j9TMnj2jGXeOTPX+rXOWkqBnMelWN+Pc27b4H33V8tVwEawPUgSOe8paW+/eiHnAAAAOSbnbe2ffcbKKEZP/0BKKdZ442dvRQYT5VwkefT0pSpg32V7kCRy3kfSweS8BDkHAADIHTnXk8q03ry3ZGCmZPCsG9/3xt6yOl5fjQw6ci5yrPXfo6ctUQEbx/YgSeT8EEnHiH95ReQcAAAgh+Rce9705/E6yaBMyeCoqe95Y3+zyj8JERncK+fxk0HXiCwvVgGbyPYgSeS8b8Q/T6QKOQcAAEDOmy+DNyCDoZJztgdyDgAAAMg5MoicE+QcAAAAkHPknO2BnAMAAAByjgwi5wQ5BwAAAOQcOWd7IOcAAACAnCODyDlBzgEAAAA5R87ZHsg5AAAAIOdhksHFa2NeIrFYzNuw3fMWLI95Vzwa3e81F99f772zJubd+3oMOQ9hmrpN71wQ85ZvjHlffBnzPpLHWX+PIucAAGBWVFCwori42Gskr8lsl+uwPA4LQ5sLCwt/Ye0Z5IweXFRUNF/+ns8li2We6+wfRSoFkqQveSfn/1jpefOXxuJ58cOYt2KTP36jCJ3KeDC/it3bq3zhm/c+ch5mOf862/SPb/rjPlwf855eHPM27fC37d2vxXJNzgkhJN+SMtGdKVL7oEakdpEJ+evBOJPcsMt5nbR9l2S5TpN2P63TZfimNMh5oaUoIcWkSWno/WuVT3L+s8f37S09X/LBOn/a9PlR7389XO9t371vjyxyHm45/6pt+r376r2d0lu+arPnXXivP8+P/ysan6496Vku59WSUr4bCSF54i1FjhOm9RfDq1VqRW4vShgfajmX5zfb88HBLCLq70i2pOjNKnCEvNh6h8ok5ZYKcsApd97L1pIOkj75KOea55b402b+Lepd+kC999cPYvG8/1kMOc9COU/cpv8xN+pt2xXzHv1XdB+B14OwlZ9nrZwfJuksaWOfab4bCSH54i4lliJH0jMr5zL+QsmjIr0b5PFJGT/KEebZkgdk8FQtK5H5X7ZJQ2X4JRm3WUtkGlj2GB0v07fpPLbcfs70WlnuvTJtva5XhmdJprlyLsOvyLS1CQL/R5unJsViXmYbpspkso2tgzQ9bew9rLb3s631wB2sB1qrn+qfdz3n67f5PeRXzd132u2vRJHzLO05T7ZNNdqT/qd/+q91hT3L5Fy/r7tI2jmfZb4bCSG57i5VTodEWgW9UTkXAd5kZS6TVYZVmO1nTBXkl+X5KslWGX5R5puiPe3yPCrLmyfDl8q4+02Yf2rLHaLTJe/K8BU6XobXqdwHK5b5n7cSlfvk6ZUybYlkZ0JZy2mSU5z2lss8KyWrU9hrHoi5ll54JG3Rf/KHSo7LdTl/aVnMm/tONB6tPdaTB5VnFu8v4Mh5dsh5U7aplrnUR/3X6Umj52fvCaH9Jd0lHfn+IoTkacrMEzMv51pO4vRMTzFBPjOQc3s+2TnZ9C2tY7ejiTiy7Kdk3EY74hghy7lDHo90lnuPLUd7YIbYen/vdorrQUADJ4QGVMo6HrG/4+JUVNFY+0vsCKk1O2Fa091+Jj9+1V/6583VWgL05MDJf4ki5zlwtZav2qZa4vKYSPyyDTEvKld2+fPCrC1rOVzS00pb+A4jhORjKpxzbjIr5/I40pHsc23e7yfIeVBG0kokOqa94iLXtwSReRbYfANtvm66Ppl2ozw+IfPX2/Q2Ktc2fHZCycqdSeR8oK5Pl+H0zqdKzkut17zGSi+624mLh5hMkqbnUKsv13/sXXVfsOG8kPMp8/xLJGp++FB9/DKJypadsXi5A3KefXLelG0aZNLv6uNX49FLL/77n7JSzgdIettnuCvfjYSQHE5f+26rs++6TlaS28o8sbgl5HxYY3KuJS3OazpYKczbItMzEmNSNkZFWrJQxk2VZU2SPB7IueQyGx6e0J5rGpDz07XcRcteZPjEVJ5/ipwj55k6eXCJXdnjqseoOc+VE0Ldbfqbl6Lex3J5RX105wkurzhtfhQ5J4QQ5Dylcr55n2JtqUl3TgwN0NrwH2lduEx7QevYrVYnWO5jjpwPtbKWa90F6PXME+T8ZFnOF3qyasS/VnYkDXIelLVou2rtJ1zdML1sI/UhTUqd/UPvYf/QD3Le07yV8+DKHtc/i5zn2tVadJv+8hl/Oy5YEWvw9T9/IprNZS1dEj7HfDcSQnLRXXrZd1xn88HW5p4tVtbSJDkXfm5yfb2WnOi8Ms92PcnTlvGM9pxrj7l9wV8uz3fbuk6y+vJFkh0yfInKuF67PLhBUiDn8vqHbD0zdV1urLY91SeEqqC3txOggn9GXUiT0tneu062c+uVHjqYqMdPCM1HOZ+7KLrnsnvIeW7IubtNtYRFL5moJSxvrIx5t8l2fWW5/1qtPb/g3qw/IbQ9342EkDxwl+D7ro15YcudEHoAcl4ignyD3iAoEGo9IdT+KGWwTPskmGblLdNseKXNUyfPX3Xm0bt/TnXkvEhPME12h1NnXc2V82SXUnQvr9OWfO24lySqtrS1nV5/Msq7Sylq5vzdFzkVNuQ8N+Q8cZv++JHonuvWB2hP+g8erM+1Syny3UgIycVk/FKK6aLEvsA7NjKtszMuqF90qbXxLQE3Icr8TYhyVs7DHuQ8M9GTRq/876h30R+y+++IcBMiQgg3Ico6Mc8VAkEvdESd21On7la4JfbTUK3VdA1CBpFztkdWyHlf+8Wr2qm55LuREJLr3lLkOGEBYg65eOBTZCdUtEfOkXO2R9bJeSf7ibeEf1IAAADIOTKInBPkHAAAAJBz5JztgZwj5wAAAMg5MoicE+QcAAAAkHPknO1BkHMAAADkHBlEzglyDgAAAMg5cs72IMg5AAAAco4MIudIMHIOAAAAyDlyjpwT5BwAACB/5VxvidtO0ltybMZkcKrI4C2rkcFEOZ+9VeT8M2/0tCUqYOPZHiSJnB8q6Rjx7/CLnAMAAOSgnPeUHJMpGdSeYZVB7SlGBhuQ8+lLVcDOYXuQJHJ+MHIOAACQm3JeLqmRdJcMyJQMqnyqhKqMIoOOnM/Z5p1z2zrv7BnLVMBGsT1IEjnXX7q0HK0SOQcAAMgtOS+TtJZ0jvg/lQ+WnCI5SzJOcr7kgmZEXz9Be4EloyVnSE6XjLTn59j085q5nmzOJMlEe7/1PRkhOU0yVDLM3rMxkvFp2B5n2vY4w56fa205P4+3R9j2Dd3u37V94URJf0k3SduI/8tXMXIOAACQG3JeKCmN+CeV1Ub80hb9x3+c5GTJqSaKI03eDiQjTP50Wd+SfENykj1+y8YPdwQxHzPC3gN9L75t783xlhMk35R8x4Q9ldsjWNc3bB3ftvGn23xnkFDsG8Ns+w+RHBnxT97uZAfVZXaQDQAAADki59rrpr1vbSJ+DasKul4J4gjJwIjfk35cM6KvH2TLOtIywJZ/lI0flIL1ZHPc9+goe3/0IKmfPep7dbTk2BRvj6MStsfRzjbP5+0Rtn3jWNtW/UzM9Vcu7TWvtIPrQr7OAAAAckPOg9KWUvtHr4LeQdJF0iPi17X2sRx8gOljQqHL6hXxa9t72EFAT5tW18x1ZHuC96iXvSf6HmnZQteE9ysd26OHs/xebI9Q7hu9bft0tQNoFXM9EbTMDq6RcwAAgBwi6D1XQdce9CqTdL2CS3uT9eak1tLe0s7koq0Nt3Pm6ZDHqXXeD31vapy0dd6/dG+P9myP0O4bui9U2+fUFXNqzQEAAHJMzjXag15ikl5uAqCpTGEqEpabjnXkQsoTUpHB7cH7H85U2L5QZp/TYuezCwAAADlGQYKkBylOcYqSPJKvfp/YHiTYD4LPKj3mAAAAOS7ohJDsCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5CQFlsIkKWpmki0rlesg2Z9k+18BH1EAAADIRzFXQSqWlFhKLWXNTGkDKUvh8kn2x903Smw/LELQAQAAIN+kvMAkKJDxckmlpNrSOgWpThhO1XJJbkX3iyrb/8ptfyxG0AEAACCf5LzQxFxlqNWaeYd7mcj4Odu8Cb/9wpt41y5v4t1feufdU0/IPtH9MeL3qhcj5wAAAJAvcl5sAqQ9lu0yJefj7vjcmzBnuzfhzp0i6LuRUdKQnLc1Qdce9KDEBQAAACBn5TzoNdcygnaSLpmS87G3fuaNm7XZes+Rc9KgnHeW1EgqInt7zwEAAAByVs61N1J7JbXWt5OkLlNyPubmld65t2+M955T2kKSyHlvSYeI33tegpwDAABAPsi51pq3kXSV9M+UnJ89Y5l3zsy1fu25lrYg52R/Oe8b8XvPW9tBJHIOAAAAeSHnWtvbU3JUpuR89PQPpLRljTd+9lbknCST8wGSbnbwWIacAwAAQD7Iudbzar25lhAMzJScn3Xj+97YW1Z742dtQc5JMjk/WtI94tedl9v+CgAAAJDTcq4ng7aX1EkGZUrOR019zxv7m1X+SaHIOWlYzo+J+L/otEXOAQAAADlPp5zfgJyTr5Tzgcg5AAAAIOfIOUHOAQAAAJBzQpBzAAAAQM6Rc4KcAwAAACDnyDlBzgEAAAA5R84Jcg4AAACAnCPnBDkHAAAAQM4znsVrY14isVjM27Dd8xYsj3lXPBrdZ/5rn6733lkT87btinkrN8W8R96Oehfei5wj5wAAuWIgBQUriouLvUbymsx2uQ7L47AwtLmwsPAX1p5BwbiioqIJ8re8JdkuWSTP/y0NskbyK8h5BuX8Hys9b/7SWDwvfhjzVmzyx28USb/4fn/e65+NxsV9zRbPe/K9mLfEXvvSslheibnuD0nknM8tIYS0XFImujNFZB/UqNSakL8ejJPp12WBnI/Q59L+N7W98rhMn0v7z0+DnBdaihJSTLI+idu0RNJKUoucp1/Of/b4vj3k50s+WOdPmz7fn7ZsQ8z7MhrzfvCgP8+k3+2d54cP5aWc95K0s4PIEr6TCCEko55Q6KQgXd57tUntRQnjQy3n0t6/ipBvsx4kpb/9HX9OoZgXOv/w9J9gmfVWaSpITqXc2b6tJR0kfSSDkfPMybnmuSX+tJl/i3rfu68+Pvzumn17yZ9415/nmr9E80bMJ961O/j+q7P9s7UJOp9fQghJvyMEnlDqSHvaBL1ROZfxF0oeFRHeII9PyvhRjjDPljwgg6fK9MUy/8s2aagMvyTjNmuJTAPLHqPjVa51HltuP2d6rSz3Xpm2Xtcrw7Mk01w5l+G/ybi7ndeUy7y7ZVkPp0HMy2zjVNk/xDaSGpJT0e1abdEDvoMkhyDnme85X7/Nr0G/am40Xtryxzdj3ozn953v/c/81//Ph/NAyk3MJ961S7//jrP9srOVXtXwfUQIIRn1hEoT9ZJ0Cnqjci7Cu8nKXCbL8FoVZjtqUEF+WZ6vkmyV4Rdlvina0y7Po7K8eTJ8qYy736T6p7bcITpd8q4MX6HjZXidyn2wYpn/eX2NvPY+eXqlTFsi2ZlYc25oCcK3tcdc55HhkSmU80DMdR0eyat0lfRVGULO0yfnWjc+951oPE8v9k8IVZ5ZnLye/LZXovF5Fq7y8qPH3ORc9wnZH4+XHMbnkxBCWjyuoGdWzrWcxOkpn2KCfGYg5/Z8snOyqZ6guSjiXEVAlv2UjNtoPc8jZDl3yOORznLvseXoEckQW+/v3aoWPQhIIuffCk5k1Xp5e7OaXUXj1B9X2NESO2J+pYdJ0PHIeWau1hKwaYfnTU5SrqK96Hpy6DrpXQ9q0PNDznd5E367Q/fLEySH8/kkhJAWT6VT4lKY6ZrzkY5kn2vzfj9BzmuCXmyR6Jj2iotc3xJE5llg8w20+brp+mTajfL4hMxfb9PbyPOLbfjshJrzO5PIub4xddom7cGXx2dTKOel1muuf18nSXer9zzExI3kRg61+nK9CkY32849rdQKOU+jnE+ZVx8vXdHoyZ33vu6P37IzFq83D+a/6A/13j8/9eVdX3vZg/lzEmiCnJ8oOcL22YMth9ivPHyWCSEk/Z5wkJ2UX2Udwi0i58Mak3MVYuc1HawU5m2R6RmJsT9sjMq4ZKGMmyrLmiR5PJBzyWU2PDyhPdc4cq61lv8hOSVB4GdryYxNR84Jcp6FJ4QusSuxXPWYP+1CkfS3V/nXQX94YSx+tZZ8ukILck4IIch5U+V88z7F2lKT7pwYGqAS/SP9I2TaC1rHbrXcwXIfc+R8qJW1XOsuQOaZ78h5vIfersfe0DwHpbisRdtVaydhqbj1MknvQ7I+uh172weuq+07XShrafmrtej1zfe5estL0by6rvlXlLX0se+hnnwfEUJI2j2hl3mB+kEH67StNJcNv5wLPze5vl7LWKzcZLue5GnLeEZ7zrXH3P7JXK5XWbF1nWT15YskO2T4EpVxWdZNQV15ZO+lFB9WQderusjT0fJ4s7VtfppOCG1jPfIdTeA620Yi2Z+D7JeRWmcbc0JoC8n53EXRPZdS1F7yHbtj3q76mPf80v2TeCfRPDohtKftu534PiKEkLSms+MJwVWyqiL7X7El1HJeIqJ8g4zf5Zyo+ZQJjzJYpn0STLPylmk2vNLmqZPnrzrzLNYSmISa8w56iUdnnpg8f8iOaFIl58kupeheWqctyfokXkqxXYRLKbaYnM/5uy/nryyPeZOfjHqNoTXrXEpxz6UU+SwTQkjq/SDZpRTdk0HTdjOiVFNiNbsdG5nW2RnX23orXWptfGNUWw98dYrbz02IuAkRNyEiYbwJUZ8INyEihJCWvAlR4jXOs0bOc4FA0AsdUec22bl9a94SK2OqtTqzQcg5CYugR/wrXvWyX3cqnX8QfCcRQkhmPKHI8ULEHCADB2NFJj3tkXMStpic97SfW8sjzv0kAAAAAJBz5Jwg5wAAAADIOUHOkXMAAABAzpFzgpwDAAAAIOcEOUfOAQAAADlHzglyDgAAAICcE4KcAwAAAHKOnBPkHAAAAAA5R85JEjk/BjkHAACAfJNzvVWv3oGxt+TYjMn5VJHzW1Yj56QxOT9a0sPkvAw5BwAAgHySc+2hPCZTcn7WjYvjcj5+1hbknCST8yMl3SU1yDkAAADki5yXm/yoBA3IlJyPnr7UG3vrZ9742VuRc5JMzvtLukham5wX8rEFAACAXJfzMpOfzpJDJYMlp0jOkoyTnC+5oBmZZMuYaMs7VzLWhsfbtEnNXAfJ/pxn+8YoyXckx0oOlnSSVEtKkXMAAADIdTkvNOmpktRG/NIW7a08TnKy5FTJCMlIyRkHmJGW0yWn2TI1wyTDneU3Zx0kuxPsH7pffFMySHJYxP81R0uu9KTlEuQcAAAA8kHOiyN+3XkbSUcT9L6SIyL+pewGm6w3N7qcY+1xkCVY9vEpWgfJ3ui+cIztd/oLjp4I2iGyt6SlGDkHAACAXJfzoLRFe88rTdBViLqYHOkVXPpYDm5G+jipsyQut7nrINmdOtvfdL/TEqtaE3M9cCyx/RQ5BwAAgJwn6D0vNRGqMknXcoL2JuvNSW2ScW46kLxOsB/o/tbWpFz3w3LbLwMxL+DjCgAAAPkg54UmQCUmQ+Um6prKFKdVwiMhbsodKS92xJxecwAAAMgbChIkPUhxGlLiDKdrHSS74wo5PeYAAACQt4JOSBgDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkAcUSAqTpKiZSba8VK8njEn2nhZYAAAAAAAaFPNAKIslJZJSS1kzEyynJGG4JMXrCWPcv7U4QdoRdAAAAABIKubFJpPlklaSKkm1pHUKU23LdZefjvWEKcHfWGnCHog6gg4AAAAA+8l5IOYq5VVr5h3uZSLj52zzJvz2C2/iXbu9iXd/6Z13T31exCS9NEHQAQAAAADicqiSqD262rvbLlNyPu6Oz70Jc7Z7E+7cmW9y3sYR9KDEBQAAAABgj5yrLLaVdMmUnI+99TNv/Kwt1nu+K5/kvFPEL3cpj+ztPQcAAAAAiIuh9uBqr3lHSV2m5HzMzZ94596+UeR8R77JeXdJezsgKkHOAQAAACBAyyq0pEVLLbpI+mVKzr/7q+XeObeti9ee55mc97EDoSrkHAAAAAAS5VzLK2okPSRHZkrOR09f6p0zc61/YqjUneeRnPeVdI74V3EJ6s4BAAAAAPZcpaWdpKdkYMbkfNoSqTtf49ed55ec94/4v1Jo3XkZcg4AAAAADcl5L8mxmZLzs25cnK9yfrika8QvJULOAQAAAGA/OdcTFHtLBiHnaZfzAcg5AAAAACDnyDkAAAAAIOfIOXIOAAAAAMg5cg4AAAAAyDlyjpwDAAAAAHKOnAMAAAAAco6cI+cAAAAAgJxbFq+NeYnEYjFvw3bPW7A85l3xaLTB1/37n+q9f62OeW+sjCHnAJB7FBQUrCguLvYayWsy2+U6LI/DwtDmwsLCX1h7BjUwuaNMe0nm+X2q3ypCCGnB5Kyc/2Ol581fGovnxQ9j3opN/viNIukX37//615Z7k/ftMNrCTlnXySEuEmL6M4sKip6UCOivsiE/PVgnEy/LpvkXNr8qE6Tv+WtNMl5oaUoIcWEEJLiuN8xpZJKSa2kLpfk/GeP79tDfr7kg3X+tOnz95326xej3q4vY97nX2RUzmvswKiY731C8vp7uDAhBZnw3qtVbEVwL0oYnxVyLu2+UKR8h2RNiuW8wBFy3VAl1otSbqkghJA0ptzEvFrSSdJHMjhX5Vzz3BJ/2sy/7Z126QP13padMe8Pb8S8ZRtiaZXziXd/qf9jjpB0l7STtHK+8/neJyT/voPLzf1KHXHPiKQ3Kucqv9ozLeK7QR6flPGjHGGeLXlABk+V6Ytl/pdt0lAtM5Fxm7VEpoFlj9HxMn2bzmPL7edMr5Xl3ivT1ut6ZXiWZFoDct5dpn8ujz+WxzdTKOeJYl5mG6pK0tp+7qwhhJA0prU9qiR2kRwqOT6Xe87Xb/Nr0K+au3fa6x/HvI82xrxJv6tPq5yrmE+8a7f+jzlS0kPSwb7rW/O9T0hefw9XOwfqpY6gt5yci/BusjKXyTK8VoXZGhdRGZfnqyRbZfhFmW+K9rTL86gsb54MXyrj7jep/qktd4hOl7wrw1foeBlep3IfrFjmf15fI6+9T55eKdOWSHYmyHmBrOMZOyAoTJOcB2KuG8UjhJAWTF/9/swVOX9pWcyb+040nqcX+yeEKs8s3nvC58yXol5UThYNRD5Dcn6UpJfkIPY5QkhCMibojcq5lpM4PeVTTJDPDOTcnk/eY7UiyFrHHnHOcJdlPyXjNlrP8whZzh3WOxEs9x5bjh6dDLH1uid3qnyvSpDzH2o5izweYutNpZwHveYl1mPemh2SENLCOVxyQi5erSVAxXvyX3wR/+FD9d62XTHvsXf29qKnVc5FzCfetUvf56OthKgr+xwhJCGtnHNRWk7O5XGkI9nn2rzfT5DzGpullQhyTHvFRa5vCSLzLLD5Btp83XR9Mu1GeXxC5q+36W3k+cU2fHZCzfmdjpz3ltdsl8efOAcF6ZDzUtsQNVbz2d1OytIDgsMIISRNOdQEUb9vett3jp6oeGKuyPmUefXxq7JoVMTvfd0fr/Xl37uv3nvi3Vj8JNAZz0e9a5+pj2fNFs/bKtN1WGvR0yznWtrSzR6DbdCXfZOQvPse7mmlhbXWiVxhnbdFLSnnwxqTcy1pcV7TwUph3haZnpEY+yPHqIxLFsq4qbKsSZLHAzmXXGbDwxPac40j52fZepZayUu87MWyxNaDnBNCkPMsOiF0iV2t5arHot6zS5L3sCu/eiGKnBNC0v09fHCCnLfOFjnfvE+xttSkOyeGBpwi+ZH+FCDTXtA6dqvlDpb7mCPnQ62s5Vp3ATLPfEfO+2q5jRtZ5mq9YouV4XRIcVlLG9sonU3Qe9k/zT6EEJLiBELewxJ0CuRUWUtjV2u5/tmo9+NHot5/PrVvVm32e851+JI/pb3nvJt953dN+N7nu5+Q3P8Odr+Hu1oHbVsrz3YvsZodci783OT6ei1j0Xm1BEVP8rRlPKM959pjbv9sLpfnu21dJ1l9+SKrJ79EZVyWdVNwg6RIwzchimTghFAVdL0RSEc7UaizHUkRQkiqc5D9MwjS03pyhuSynM9dFN3vUopuWuCE0FoL3/uE5O/3cK2JuZa0VIbihNADkPMSkekbZPyuQKj1hFD7clMGy7RPgmlW3jLNhlfaPHXy/FVnnsVaAtMCcp7sUoruZXbaEkJIipN3l1LUzPm7L+d6N9AWlPOvcylF9lFCcvv7N0ibyN5LKVY4Yl4UyeANiVKJloT0c6S8oWmdnXG97acDl1ob3xJwEyJCCDchSrGchzlJbkJUwfc+IXl/I6JS88CM3YQIvlrQCx1R5xbOhJBM3Tq61AS91mogByHn6U3EP/G2m/WalSdsD/ZNQvLve7gowQURcwCAPKbYBLG9/YqInGdGzrvaz9llEeeeHQAAAACAnCPnyDkAAAAAIOfIOXIOAAAAAMg5cg4AAAAAyDlyjpwDAAAAAHKOnAMAAAAAco6cI+cAAAAAgJwj5wAAAACQpXJ+LHKOnAMAAABAy8q53kq+l2RgpuR89LQlvpzP3ppvcn44cg4AAAAAjcl5W0lPydEZk/PpS0XOP4vL+cS7duWTnPeTdJG0lpQi5wAAAAAQoGKovbfai9tNMiBTcn72jGXeOTPXeuPnbMs3OT9E0klSjZwDAAAAQENyrr24B0kOlQySnCIZLRknOU9yQTNyvmS8ZIxklOR0yTDJcHs+1qY3dz1hyyTJBPu7R0i+KTky4pcP1UpaSUokheyGAAAAABDIeYmJop4U2kPSXzJYcrLkNJPpMw4wI01MVcSH2jJPlJxgjyfb+GHNXE8Y4/7d+rceHfF7zbWkpUZSgZwDAAAAgIuKYVB3rqUtHSN+7XlfyRGSgSbqxzUj+vpjTU6153iAHQAMsOdH2/TmrieMGWR/n54E2ifinwiqB0FVkb0lLcg5AAAAAOyR86D3vMIEXUsutHdXe9F7m1QefIDpY6mL+OUcuszuTnra+LpmrieMcf9urefXOnO9Kk61HQwVI+cAAAAA4FIQ2dt7XmqCXmWSrldwaW+yrunQjLS3tLPlBmlnSdV6wpZa+9u0jEXr+luZmJc4Yl7AbggAAAAAAYWRvT3oKullJpCayhSlwnkMll3hpDKHE/zNZXYAVIyYAwAAAEBjFCRIeiDqqYy73MTHXE+RI+SBlCPmAAAAANCooJPMBQCgyfx/I9Z+uHcWfZsAAAAASUVORK5CYII=)

- ExecuteProduceConsume：任务生产者自己运行任务，但是该策略可能会新建一个新线程以继续生产和执行任务。这种策略也被称为“吃掉你杀的猎物”，它来自狩猎伦理，认为一个人不应该杀死他不吃掉的东西，对应线程来说，不应该生成自己不打算运行的任务。它的优点是能利用 CPU 缓存，但是潜在的问题是如果处理 I/O 事件的业务代码执行时间过长，会导致线程大量阻塞和线程饥饿。

![img](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAucAAAEHCAYAAAANq+jXAAAyNUlEQVR42u2dCZgU9Z33e+7hHI7hFORSETXEIKhrjEFuUBPXXeOFJo9uNnHzvskq67pvEjEhXoCYmMRN1DUiJiSiRhbRKKAoEAQxCoRrkFMuueUYLqf7//5+Vb+CmmYGR5ijavrzeZ7v09VV1dX/6a6p/tS/f/XvRAIAAAAAAAAiT5Yku5LkRDCVtTMu7a/L1ynb3u8sdnsAAACA6Ip5IHS5kjxJvqUgggnalmftDdocTlTbXlevU/Ba5SDoAAAAANEX81wTuUJJI0ljSRNJ04imibVT0zCUxjFoe22/To3ttSm09ziQdAQdAAAAIGJyHoi5ilvjn68Y6qKeR5b7Gbd0qHt48RA3ZuFgJ21veeP4MkdOHDuZKbD3PBs5BwAAAIgO2SZpKmvau9oiLnI+bpkv52MXDXYPvTdIpbMT8l0lOW9ugp6fONZ7DgAAAAARkvOGJm3t4yTn2ms++v1B7v55A1U6z0O+qyTnbSVFkgYJvw49m38DAAAAgOjIufagaq95a0nX2Mi512s+RHrNB7pRc/qrdF6CfFdJzjtLihPHes+RcwAAAICIoGUNWtKiPantJT3iJOdaa/7Au4PcT97up9I5EPmukpyflfB7z5vYe5/DvwEAAABAdORcLwRtJjld0jNucq4lLSPf8OT8KuS7SnJ+ruQ0OyFDzgEAAAAiKOctJJ0kveIg5169+RIZpeWDwe6+dwa6e2b0Vem8Bvmukpz3lHS0E7JC5BwAAAAgmnLeWXJBLOV8+uUqnd9Avqsk519M+N+SIOcAAAAAEZXzlpIukt7xk/MBgZxfh3xXSc7PNzlvjpwDAAAAIOfIOXIOAAAAAMg5Qc4BAAAAkHPkHDkHAAAAAOScIOcAAAAAyDlyjpwDAAAAAHJOkHMAAACADJbzTQeWu3QOJ0vdptLl7s2tj1f4mMkbRrmNpcvc79f+IHZyXrItddzfm0ql3M5S5+atS7kRk5PHPea2iWVu6ccpN2FBCjkHAACAkyMrK2t9bm6uO0HeldW+r9NyOygKbc7Ozv6ptad32qIGMv8tub2rJl6qGOY4OX9k+anJ+Zr9C9ySPTO8lOyd4w6V7ffmz9sx6ei6v1hxpfvfjT9zpZ/u9pY9v/7/xVbO/7bBuZmrUl5mrU659bv9+btE0lXGg/VV1hdv9iX+9RWRk/MsQgghhNRYql10H8vJyZmkEVFfYkK+IJgnyx+IgZzrC/MFae9rOl//phqU82xLTlpyI5SgTXmShpJiSdfqkPOJa+8oN//p1d/2epS1F12l/M2tT7iy1JFyPc5xlvMfTi3fQ36T5MPt/rKHZybd/32hzJUeKd/LXsdy/qWE/2uwLe29z4vg/kkIIYTEKenOlx1KVk177z0qtyK5t6bNj7Scy0nFynBvfw3IeVZIyHNNeAqsZ1LTIKJROWsqaSs5U3Khiu/JCHplcq7Zd2Snt+yJVTe7lzb89GjPejC/Psm55o2V/rLH/pp0332uzL35YcrLiq2pKMi5/k+cYe95M0mjCO+fhBBCSJwSeJ86YH5I3ANRr305l/m3SCaLDO+U21dl/lUhYX5C8pxMDpDlJbL+HFvUT6Zny7w9WiJTwbav0fmyfL+uY9vtEVpeLNudIMt26PPK9OOSsWk95z+WeY/IY1+qATlPF/MCe4Mam/gWmQRFLUG7tNe8g6S75KJxS335/byCXpmc/+bD610yVeb1nv+y5Opyy9aWvl8ve853+JU87u4p5Zf9Zm4yCnJ+keRsK21pLWkR0f2TEEIIiVuKzP0amwsWhL6hrhs5FznebWUuI2V6mwqznTkkVMbl/mbJPpmeJeuN0p52uZ+U7b0u09+VeRNNqu+07V6syyXLZHqEzpfp7Sr3wRNrDbkJ97NaS6695JJDldScD6tBOQ/EXHsiXUxzycOLhzgV9JOV81nbxrspGx/0Mm3Lo27rwdXe/FX75h/3mPog57PXpNyUpUkv00r8C0KV6SXHC3hE5JwQQgghtZcCc8QaK3E5oZxrOUmop3yUCfKVgZzb/ZGhi00Xah17IjRihNaFy7xddtYxVLbzW7ntGdrueNtOE5V3e97fh6ta9CSgFuU8O1S/3cDOmOK6A106dtFgT3xVgE91tJaALQdWuidX3VIv5bwidh9wbuRfksg5IYQQQsLXd9W+nKv8hiT7Wlv3W2ly3sxWaSQSndJecZHlXwWRdebZer1svQ76fLJsjNy+IuuX2fIiuX+bTV+dVnP+VB3Ieb71muvf10bS0S6yPNPKCKKWs6xtenuOXSh42ZiFpybn82VUlmlbfu1l6qbR7pm1t3sXglb0mPog56Ne94dI1Hzv+TJvmERl76GU++azkZTzy620RUdtOddKxM4mhBBCyCmlu3lVV3NAdcHm5ob5Ndl7XuULQiuScy1pCT2mlZXCLBZZHpceWd5N681VxiWLZN5o2dZwydRAziW32/TgtPbci5zXjZxXdEFoZamPNeealTZay90vJ5FzQgghBDkviLKc7ylXrC016aELQwP6S36gV7vKsre1jt3+qGC7L4fkvJ/J9n3hDcg6M+uwrKXILrJsZ29OZ3ujukUo2p4uobZ1t9KhUy5rQc6Pjdby4IxIyvlX7f/iPDsxOyNi+yYhhBASt3S1dDb3a2cuWGRlLfmhi0KjLefCj0yWH9QyFl1X1im1HwrSbUzXnnPtMbdevu/L/SP2XF+2+vIlkgMy/R2VDh2VJRgysQ4vCNU3Q8eR1tEw2tqb1D5CaRdq12km6vr6fjm4IBQ5P3k5n7IkeXQoxQjK+aV2IqZS3sne//aEEEIIqRa3am0OWBTqNc+rswtCT0LO80SUH5L5hwOh1gtC7Q9T+siyjcEyK28Za9MbbJ2ucn9+aJ0SLYGpAzmvbCjF8BA7zSOScHuK7SxPe88vDnrNq2soxUyU8yff8SV87rpUXIZSbE4IIYSQU/aq8FCK2mNemKiFoRRrijyrfW19gmXtQvO6WI9fmGKbXxfUqx8hOtkfIqqtREHO45oEP0JECCGE1KsfIYLPFvTskKjnJKL70+hBnbwKeiurleqjUh5lMUfOT1nOv2Q1cS0Tx4Z34qeXCSGEkFP3qnDCTpiFJkNVybEzvJb2rUPvKEs5cl4tcn6+lbQ0t/c+h38DAAAAAOQcOUfOAQAAAAA5R86RcwAAAADkHDlHzgEAAAAAOSfIOQAAAAByjpwj5wAAAACAnBPkHAAAAAA5R86RcwAAAAA4RTm/IMZy/g3kGzkHAAAAqA9y3iLh/2pkr1jK+Yy+Kp3/jHxXSc57Sjoi5wAAAADRlXMVtU6S8+Mm5/fPG+hG+nL+j8h3leT8PEkHSTPkHAAAACB6cl4gKTJhOy8ucj5u6VA3ZqHI+fwB7t6ZXlnLFch3leT8bEl7SVN775FzAAAAgIjJuYpaW8lZkt6S/pKvS74huVFyc4QyXHKD5FrJVZLBkn6Sy63dQyVXS66LYNtr+3XSv/+f9cRF8lXJlyTdJK0ljSX5yDkAAABAtOQ8T9Io4V8UqhcKniPpI7lMMlAyxOQuKhlmQt7fhPMSa6+eVFwoudREPWj7sIi1vy5eJ31NLkj4veb6DYleY9DQ3vts/g0AAAAAooGKWW7Crz3W0hbtUdXa8+6SL0h6mfheGLGoiGsvcE87mehu4tkj4ddUfzHCba+L10lfkzMT/oWgxZIm9p7nIucAAAAA0ZLzoPe8gQm6ypvWJGsvug6vqGUQZ0Qo2p6u1jZto/YEnxZKRzvBCNoetfbX5uuk6WyviZYt6bcjTe29zrP3HjkHAAAAiAhZiWO95/kmbY1N0pubzBVbWkUo2p4WFm1ns1Ca2/yWEWx3XbxOLe010fdUy5cKEXMAAACA6JKdONaDrpJeYAKnaRjhNLAUpqVBKA3J0deiwE7AckNijpwDAAAARJCsNEkPRD3qqaitcWp/bb9OSDkAAABAjASdZE4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMoAsSXYlyYlgKmtf1Nudqals38riXw8AAACgYjEPRCpXkifJtxREMPlpyatgXgGJ3PuVZ/tXWNoRdAAAAIAKxDzXBKpQ0kjSWNJE0jTCaWLtDNraJAZtztQ0sf2qgQl7HoIOAAAAcLycB2KuUt745yuGuqjnkeVD3bilQ93Di4e4MQsHu4feG+RuHF9GYhST9EDQkXMAAACAhN9rqWKuPZna+9wiDnI+bpmI+ZIhbuwiX8zve2cAwhs/OW9igp5r+yEAAAAAcm5y1FDSXNI+NnIuveaj31cxH+h+8lY/hDd+cl5sJ4RaShX0ntODDgAAABkv5/kmSa0lXeMi52MXDZFe84Fu1Oz+7oev9UV44yfn7SXNEn45VS5yDgAAAOD3WGpJS5HJUo9YyPnSoV5Jy/3zB7h7Z17u7p7yVYQ3fnLeSdIy4X9rg5wDAAAAmJxrz6X2YJ4u6RkXOdcLQbWkZeSMvu4//vwVhDd+ct5N0srkPA85BwAAADgm5y0Sfk9mrzjIuV4MOuaDwd6FoPdMv9zd+fylCG/85PzMhF9K1Qg5BwAAADhezjtLLoibnP94Wl93x3NfRnjjJ+fdJW0S/vUOyDkAAABASM619reLpHec5Pxncwe4H72OnCPnAAAAAMg5ck6QcwAAAADkHDlHzgEAAACQc+ScIOcAAAAAyDlyjpwDAAAAIOfIOUHOAQAAAJBz5Bw5BwAAAEDOP3c2HVju0jmcLHWbSpe7N7c+Xm7d/155nfv7J6+7vUe2u4Nl+9ya/e+5iWvvyDg5L9mWOu41S6VSbmepc/PWpdyIycly6z81L+XW7Uq5g5+m3Fq5ffydJHIOAADlycrKWp+bm+tOkHdlte/rtNwOikKbs7Ozf2rt6R2a3ScnJ2em/D2fSEpknQfsA6PaXipCIphql/M1+xe4JXtmeCnZO8cdKtvvzZ+3Y5K33i9WXOm2HlzlzVshy1fum+vKUkdE5A+68au/k5Fy/rcNzs1clfIya3XKrd/tz98lkn7bRH/dP77vz1u9I+WmlaTc7gO+zD/9bqq+yTkhhGRKakx0HxOpnaQRqV1iQr4gmGeSG3U57yptPyxZp8uk3dN0uUw/UgNynm3JSUsuIbWQiva7BtUp5+k94E+v/rbXG6y96CrmUzY+4K23YOefj64za9t4b96c7RMyUs5/OLV8D/hNkg+3+8senpl033y2zB2S3vLNe5y7ZYK/zr//Oekt1570mMr52ZK2kqaSAo6FhJB6/nmbE3LAWv2m8B6VWpHbW9PmR1rO5f6jdr9PsIqI+lLJ3mp68bJCQp5rvUQF1mNZaHJESG2mMLQPas9lKz1JrQk51+w7stNb9sSqm93c7X/wetP/uG7E0eUvfjTSWz53x0Tk3PLGSn/ZY39Nuv+cknT7D6fc5L8nywl86ZGU2/BJbOX8HMlpkha2D3IsJITU98/cPEtOSNLrVs5l/i2SySK9O+X2VZl/VUiYn5A8J5MDtKxE1p9ji/rJ9GyZt0dLZCrY9jU6X5bv13Vsuz1Cy4tluxNk2Q59Xpl+XDI2LOcyPVeWbUsT+D/aOs2qWcwL7I1qbD1GRfYchNRWimzfa2L7YZGVF3TTE9RHllevnP/mw+tdMlXm9Z7/suTq4x6nwv7RgcXeOmFhz/Se8x1+NZC7e8rx4q496X/6wH9sWNhjJufnSTrZvteCYyEhpJ5/5jY2/yuobUE/oZyLAO+2MpeRKsMqzDKdb4I8R+5vluyT6Vmy3ijtaZf7Sdne6zL9XZk30YT5TtvuxbpcskymR+h8md6uch88saz/lpWoPCt375JlKyWH0spaBkr6h9pbKOtskGypxl7zQMwbSRwhEUt7yZmSC09VzrVEZcrGB71M2/Ko1Jev9uav2jf/uMcs2zPz6IWQr2wam7EXhM5ek3JTlia9aD25XhCqTC85vldcy1zKkv7j9KLRm+J7Qej5/N8RQjI0BeaFdS/nWk4S6pkeZYJ8ZSDndn9k6GLThVrHbmcXHrLt12TeLjsDGSrb+a3c9gxtd7xtR3sFL7bn/X24U1xPAiq4IDSgoTzHS/Z33FYdVTTW/jw7Y2rKTkkimI52gd5F45ZV32gtAVsOrHRPrrrluMe8unmcN2pL6ae73YFPP3EvfPTDjB+tJUAv+Bz5l+N7xbXE5WWR+DU7U/JtQ8q9uCi2ZS29+L8jhGRoGljndE6dy7ncDgtJ9rW27rfS5DwoI2kkEp3SXnGR618FkXXm2Xq9bL0O+nyybIzcviLrl9nyIpVrm746rWTlqUrkvJc+n24j1DtfXXKeb73mzexr3I5W43umXRhFSG3lLCth6WQ1v+1tulrkfL6MyjJty6+9TN002j2z9nbvQtATPfbJVd/0RmxZv39hRsr5qNfLvFFZNN97vsxNWODP33so5ZWwVPTY4c+UucWb/aEX//VPsZRzPf6ea/vdWRwLCSH1MN3t2NbVvE/9r7n5YL71nte5nA86kZxrSUvoMa2sFGaxyPS49JhcXKMiLVkk80bLtoZLpgZyLrndpgentefeCuR8iJa7aNmLTF9SndefIuckk+T8s8YrXyqlLNsPrZda9BvKzd9+aK0n6J8l8plyQehKG63l7peT7pezk+4jGV5Rb8PrBMMrjp2ZRM4JIQQ5rxE531OuWFtq0kMXhgZobfgPtC5clr2tdexWuxNs9+WQnPezspb7whvQ8czT5Pwy2c5BvVhVy1qq+TVJL2vRdhVL2tkb1dnetG6E1EJ0X9MhE083MW8bOlmsFTn/+yfTvPWmbhpzdN7/rP6W1wO878gOLghNG63lwRlJd/90f9jEeetTFT7+R6/EUs4vsIv3u9k+ybGQEFIfP3M722dsO/O/puaakSlr+VxyLvzI5PpBLTnRdWWdUr3I07YxXXvOtcfcemC+L/eP2HN92erLl0gOyPR3VMZ17PLgB5ICOZfHP2/P85g+VzhW217dF4SqoOu40q1NjtpZ7yUhNZ12ISHXg0QL2xdPCy4IrWk5/8PaH3gifqis1L23a7L8eugTbtvBtd5j/yrDLCLnfqYsSR4dSlFLWHTIRH3d3tuQcv89N+nmrvMfq7XnN0+I7QWhZ9iJYnuOhYSQevyZ29o+a4vMA6NzQehJyHmeCPJD+gNBgVDrBaH2Ryp9ZNnGYJmVt4y16Q22Tle5Pz+0jv765+iQnOfoBaaV/cJp6LlOVc4rG0oxPNxOc0JqOOGhnZpYiuzgoaJU7UMpVpSXpRZdLwIN0F8H9cX8CuTc8uQ7vpyrhHs/OvRS0q3YWv4CUu1J/7dJZfVlKEWOhYSQ+pg6H0qxpsizrz9bn2BZu9C8LtYTGKbY5tcF/AgRicuPEJ20nJ9MtJxFf0H00RVXfa7H1Rc5P5noRaN3/W/S3fqHeP8dCX6EiBDCjxDFVszrC4GgZ4dEnZ+rJnX9k8LBtRDByWvv2hLzU0kmy3l9iV0s1dZ6lAo4FhJC6vnnbU7IAbMQcwCojBw7o2+JnJNalvPuVtLS2E4S+bACAAAA5Bw5J8g5AAAAAHKOnCPnyDkAAAAAck6QcwAAAADkHDknyDkAAAAAck6QcwAAAADkHDknyDkAAAAAck6QcwAAAID4yvkFyDlBzgEAAADqVs71J9Q7S3rFSc7ve2eA+/G0vu7OSch5DOX8LElrSSPkHAAAAKC8nDeXdJKcHy85H+jumdHXjXjxUoQ3fnJ+BnIOAAAAcLycF0iKJB0k58VBzsctHerGLBzs7p830N375uXursmXIbzxk3Mto9JyqobIOQAAAEB5OW8qaZvwSw16S/pLvi75huRGyc0RynBr03WSf5JcLfmatfefQm0eHrF2Z2qG23v1j5JBkksk59jJoH5j00CSi5wDAAAA+HKuvZZaWqC9mKebOPWRXCYZKBkiuSJCGSYZaqI3QHK5pK+lf6jNwyLW7kxN8F7p+3SxpKeka8K/GLSpnRzm8K8IAAAAkEhkJ/xeS60719IWrQHW2nMdSeMLkl4m6hdGLNqmC6x950u+aLe9bH6fiLY7ExO8V/oe9TAxb5fwe821pCXf9kMAAAAA5DxxrPe8gQl6saR9wu9F17rgbgn/4r2opJulq7Wvi51QdLZ5QaLW7kxNt9B7dJqdAKqY67c1BXZyiJwDAAAAJPwa36D3PN8EvbFJugpUS5N1TasIpTjUtpZpKY5omzM5+l7ocJ3NJE1sPwuLObXmAAAAAEZ24lgPeq5JU6GlYQzSICbtzPQ0sH1K96+8kJjTaw4AAACQRlaapAeiHvXEpZ3k2PuVE9rX6DEHAAAAOIGgE1KbAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAOifLkl1JciKS7M+ZHJLxqWzfyOLfHgAAAKIu5iozuZI8S76lICLJDyVoY7i94XYXkIxP+v6SmybsCDoAAABETsqzTFgCqS2UNJQ0sTSNYLRdjS0NLY3sfpTbTepuX2lo+3a+STqCDgAAAJGU82wTcxWXRj9fMdRFOY8s9zNu6VD38OIhbszCwU7aXXzj+DJHyGfFTuIKQoKOnAMAAECk5DzXZEV7F1vEQc7HLfPlfOyiwe6h9wapcHVGPEkV5by5Cbr2oAclLgAAAACRkPOg11y/8m8haR8XOdde89HvD3L3zxuowtUT8SRVlPN2kmaSBoljvecAAAAAkZBz7TnUHkSty20j6RoLOfd6zYdIr/lAN2pOfxWuSxFPUkU57yJplfB7z/OQcwAAAIianGuteZHkNMk5cZFzrTV/4N1B7idv91PhGox4kirKefeE33ve1E5MkXMAAACInJxrHW4nyRfjJOda0jLyDU/Ov454kirK+XmSDnZCWoCcAwAAQNTkXGtvtd5cv+7vFXU59+rNl8goLR8Mdve9M9DdM6OvCtc/I56kinJ+vqRjwq87L7T/AQAAAIDIyLleDNpS0lXSO3ZyPv1yFa7rEE9SRTn/UsL/lqg5cg4AAADIebXK+YBAzq9HPEkV5bwXcg4AAADIOXJOkHMAAAAA5JwQ5BwAAACQc+ScIOcAAAAAyDkhyDkAAAAg58g5Qc4BAAAAkHNCkHMAAABAziWbDix36RxOlrpNpcvdm1sfL7fuL1Zc6eZsf9ZtP7TWHSordRtLl7kpGx9Azj9HSraljnu9U6mU21nq3Lx1KTdicrLc+vdNK3NLP065/YdTbsPulHtpcdLdMgE5R84BAOqb3WRlrc/NzXUnyLuy2vd1Wm4HRaHN2dnZP7X29A7m5eTkXC9/y0JJqWSJ3P+XGhBBEr1Uu5yv2b/ALdkzw0vJ3jki3/u9+fN2TDq67t8/mebNW79/kftg91S378hO7/6Ujfcj559Tzv+2wbmZq1JeZq1OufW7/fm7RNJvm+iv++CMpCfuH+917tXlKbfSHjt7TQo59/8HOBYQQkjdp9pE9zER2UkalVoT8gXBPFn+QAzkfKjel/a/r+2V2zV6X9p/Uw3IebYlJy25pFZS0eveSFJcXXI+ce0d5eY/vfrbnhhqL7r2mAf3VcyDdX635l9kXtLrZUfOP5+c/3Bq+R7ymyQfbveXPTzTX7ZmZ8p9mky5f5vkrzP8mWPrfO/5jJbzBpX8X3BMIoSQmneQ7FCyasp77zGpvTVtfqTlXNr7pgj5fvuwUs6xv+PFahTz7NAHXp6kwHqtCu0DktRuwq99kaS15AxJn0eWD3Wa6pJzTdAz/sSqm92rmx/2pt/4+Lfl1tn/6S5X+ulu5PwU5Vzzxkp/2WN/TbpvPlvmTS/7uHwv+SvL/HXu/UsyE+W8s31b1MiORQUciwghpFb9Q4+7+SFprzFBP6Gcy/xbJJNFhHfK7asy/6qQMD8heU4mB8jyEll/ji3qJ9OzZd4eLZGpYNvX6HyVa13HttsjtLxYtjtBlu3Q55XpxyVjw3Iu03+VeU+HHlMo6x6Rbb1QA2JeYG9OY0lTE8NmpNZTZK+/poWkneQsyYUqv9Up57/58HqXTJV5veW/LLna/XHdCDd7+wQ3fvXtR9d5ctUt3mO3HFiJnFdDz/kOv5LI3T0l6ZW2/PH9lBv3Vvn1Vmz1H/9/XsiM1+uGpz/1IvvKBZIukla2/zfieEQIIbUaPd42sbLaQuu0rTFBP6Gci/DutjKXkTK9TYXZzhpUkOfI/c2SfTI9S9YbpT3tcj8p23tdpr8r8yaaVN9p271Yl0uWyfQInS/T21XugyeW9d/Sx8hjn5W7d8mylZJD6TXnhn5I9dUec11HpodVo5wHYq7P4Ugkc7bkonFLfTn/vIIeyPmsbeOldvxBL9O2POq2HlztzV+1b36Fj9NSF61TV6Zt+TVy/jnlXOvGpyxNeplW4l8Qqkwvqbye/L/nJr11Fm12GfN6pcm5lnC1sRNT/vcJIaRuExb02pVzLScJ9ZSPMkG+MpBzuz8ydLGpXqC5JBEaTUC2/ZrM22U9PUNlO7+V256h7Y637egZycX2vL8PV7XoSUAlcv7V4EJWrZe3F+uUq2is/XnWY96UnTCyOUf3GZXzk+k9r2i0lgDtEdfe8fTH/ObDG9y60g+8dZbvfVvmXYGcn8JoLQG7Dzg3spJyFe1F128xtkvvelCDnmFy3ttKuNpZ7zn/+4QQUrdpGCpxya7tmvNhIcm+1tb9VpqcNwt6sUWiU9orLnL9qyCyzjxbr5et10GfT5aNkdtXZP0yW14k92+z6avTas6fqkTO9YXpqm3SHny5nVGNcp5vvebNrMeqo/VenWk9tqT20t1e965We6tf8XeTnCf5BxXfU5Hz+TIqi/aAa6ZuGu2eWXu71zuevv7EdXd4tegqiu/ufLHCdZDzz5bzUa+XeaUrGr24c8ICf/7eQymv3jxY/9Y/lLkPNvnyro+9fVJmvV4VyPlpkrYm6eHjUXeOEYQQUmM5y5yjkx2DW1iHc2FdyfmgE8m5CnHoMa2sFGaxyPS49Ngfdo3KuGSRzBst2xoumRrIueR2mx6c1p57Q3KuF0X9p6R/msA/oSUzthw5r3+pMTmv6ILQ9Dyz5t/cwbJ93gWgL340kh8hquYLQlfaSCx3v+wvu0UkffFmfxz0FxalvNFaMu31Qs4JIQQ5Pxk531OuWFtq0kMXhgaoRP9A/whZ9rbWsVstd7Ddl0Ny3s/KWu4Lb0DWmRmSc6+H3sZjr2idttVc1qLtKg59IHa2D8VupFbSNSTlp+s3L3bbxcpaalzOf73yGhmZZacn5k+tvpVfCK3B0Vp0fPNyo7fMTmaclFehrKU1xyNCCKk1Bwn8o70dg5tZWUtBLORc+JHJ9YNaxmLlJqV6kadtY7r2nGuPudw9V59HR1mx5/qy1ZcvkRyQ6e/oh5Js65GgrjxxbCjFF1TQdVQXuft1uX3U2jazhi4ILbIe+dahnqv2pNbSzl731vaP0c7+UY5eEFqTcv7Shp966+08tMEt3fNGuSza/SpyXg1yPmVJ8uhQitpLfuCIjDNflnJvrTo+6b8kmoEXhDa341ErjkeEEFIr/tHGjrvNQr3m4RFbIi3neSLKD8n8w6ELNV8zqVL6yLKNwTIrbxlr0xtsna5yf35onRItgUmrOW+lQzyG1knJ/eftw6q65LyyoRTDQ+s0JzWe8FCKRaETpfb2VdNFgZjXlJz/bdeUSi9k1FIX5PzU5fzJd3w5n7su5Ua+mnQnQmvWGUrxuKEUOVYQQkjN+EdFQymGLwatsR8jqm70bKJHSMorWtYuNK+L1VOGKbb5J6KJ9cA3qeb28yNE0f8RojaJU/wRotoKck6q8UeIGif4ESJCCKnLHyFKH+M8NnJeHwgEPTsk6vxMdt3/fG6e9RwWWz1Y7yiLOXJOqknOO1lPToNExT8pzXGCEEJq3kFyQl6ImAPYP0GOfa3U0upwe0dZzJFzUs1yXpgI/Y4EAAAAAHKOnBPkHAAAAAA5J8g5cg4AAADIOXJOkHMAAAAA5Jwg58g5AAAAIOfIOUHOAQAAAJBzQpBzAAAAQM6Rc4KcAwAAAGScnF+HeJIqyvmXkHMAAACIspzrryS2kHSRXBA7OZ/RV4XrWsSTVFHOz5ecbnJegJwDAABAVOVcexO/FCc5v3/eQDfSl/NrEE9SRTnvKekoaYacAwAAQBTlvNBERYXlvDjI+bilQ92YhSLn8we4e2d6ZS1XIJ6kinJ+jqS9pKnJeTaHAgAAAIiSnBeYqLSTnCXpI+kv+ZrkG5KbJDdHJMMlN0iutfYNkfSzDJAMk1wtuU5yY4TaTeomN9q+cpXkcskFkjMkbSRNJPnIOQAAAERJzrNNUBpLihN+aYv2LF4oucyEd6hJ7xV1nGGWwXby8FXJJdZWPaG4SHKpSdhAE/cotJvU3f4yxPbhr0h6S85O+N8QaRmXXgidh5wDAABA1OQ8N+HXnRdJWpugd5d8IeEPO9fHBDgqUcnSETd62onE2ZYekvMkX4xou0ntp4/tK7ov67dCeiFoq8SxkpZc5BwAAACiJOdBaYv2njc0QVd5aW8ioyO4dLOcEYFoO7pau/QkooPlNMvpNj9q7SZ1k2Bf0f1Cy7aKTcz1ZDTP9n3kHAAAACJF0Hueb9LS2CRdv/pvabIelRRbtF3NLc1CaR5qd3HE2k7qdl9pavt2oe3rgZhncQgAAACAqMl5tslKnolLoYm6pmEE08DaWBhqa7jNUW03qZsUhqQ8NyTm9JoDAABAJMlKk/QguRFOejvj0m5Sd/tLdij0mAMAAEDkBZ2QTAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAhMmSZFeSnAimsrZFuc3V9TenJ8sCAAAAAPVIzAMJzJXkSfItBRFMftp0fiXL6lPy7X3Js/coLO0IOgAAAEA9E/NcE8AGkkaSxpKmEU1RhNtWk2li70tDE/ZA1BF0AAAAgHoi5zkmeYUqfj9fMdRFOY8sH+rGLR3qHl4yxI1ZONg99N4gd+P4soyMSXp+mqADAAAAQEzJNrHTXljtkW0ZdTkft8wX87GLfDG/752BmSznRSFBD0pcAAAAACDGcp5ngtdCclpc5Hz0+4Pc/fMGup+83S+T5bxNwi93KUwc6z0HAAAAgBjLufa6NjHROyMOcj520RCv13zUnP7ux9P6ZrKcd5S0tJOrPOQcAAAAIN5oKYSWtDSTdJCcG3k5XzrUK2l54N1BXq/5f029LJPlvJukdcIvSULOAQAAAOqBnGtJhJa0dJKcHwc51wtB758/wI18o5+7a3JGy3l3SbuE/81HUHcOAAAAADFF65R16EQtjegi6R0XOdcLQUfO6OtGvHhpJsv5OZL2Cb/uvAA5BwAAAKg/ct5VcmGc5PwelfMXMlrOz5WclvBHbUHOAQAAAOqJnBcn/PrlGMn5AHfP9Mvdnc9ntJyfh5wDAAAAIOfIOXIOAAAAAMg5co6cAwAAACDnyDlyDgAAAADIOXKOnAMAAAAg58g5cg4AAAAAyDlyjpwDAAAAIOcnJc2bDix36RxOlrpNpcvdm1sfr/Rx/7vxZ25j6TI3c+sTkZPzkm2p4/6mVCrldpY6N29dyo2YnKzwcf/6pzL39y0p996GFHIOAPWTrKys9bm5ue4EeVdW+75Oy+2gKLQ5Ozv7p9ae3hUsbi3LZss6v6/ul4oQQj5Hql3O1+xf4JbsmeGlZO8cd6hsvzd/3o5Jxz3mtx/e6A58+om3/P1dUyIr53/b4NzMVSkvs1an3Prd/vxdIum3TTz+cXPX+ct3H3A11rYbnv60MjlnvyaEBKlR0X0sJydnkkZEfYkJ+YJgnix/IE5yLm2erMvkb1lYQ3KebclJSy4hJKOTfkzIkzSsTjmfuPaOcvOfXv1tr7dZe9F/seLKcstW7pvr9hzZFnk5/+HU8j3kN0k+3O4ve3hm+WW/mJV0hz9NuU8O1pqcd5A0kxTa+8nxnpDMPKZnpyWrNr33HhVbEdxb0+bHQs6l3beIlB+QfFzNcp4VEvJcO0gX2AG70HrHCCEkSIHdNtFv8yRnqJw/srx65Vyz78hOb9kTq24+Ou+VTWNdWeqIV9YSNznXvLHSX/bYX48t++5zZW7voZT7w3spt2ZnqsbkXMX8ht8d0c+XnpLTJS0lje1Ei+M9IZmVwPP0mJ4fEvdalfQTyrnKr/ZMi/julNtXZf5VIWF+QvKcTA6Q5SWy/hxb1E/LTGTeHi2RqWDb1+h8Wb5f17Ht9ggtL5btTpBlO/R5ZfpxydgK5LyjLP9Ebv9dbt+vRjlPF/PgQ1cP1k3tK89mhBBiaWpS3sTut5WcKbmouuX8Nx9e75KpMq/3/JclV3vzVNIPlu1zc7f/wf1uzb/Esud8h1+t4+6ecmzZgo9Sbu2ulBv+TFmNyXkg5jf87rB+vnxR0kXSRtLC3kuO94Rk7jG9kYl6fkjQ617ORXh3W5nLSJnepsJsjUyojMv9zZJ9Mj1L1hulPe1yPynbe12mvyvzJppU32nbvViXS5bJ9AidL9PbVe6DJ5b139LHyGOflbt3ybKVkkNpcp4lzzHdTgiya0jOAzHXN8cRQkgVo6UR3fV4N27Zqcn5rG3j3ZSND3qZtuVRt/Xgam/+qn3zj66rdek7Dn0ksv61WMj57DUpN2Vp0su0Ev+CUGV6ybELPh+bnZSTkNRRka9pOb/+qUP6vp1v5Ujsw4SQcGpd0E8o51pOEuopH2WCfGUg53Z/5FGrFUHWOvZE6Cp32fZrMm+X9TwPle381r4+DLY73rajZykX2/OGL+5U+d6cJuff03IW651KVLOcZ4fqRxvYGRQ7JyGkqjndvg38h1OV84rYcmCle3LVLd56r2/5hdeL/qd1d3n34yDnFaHiPfIvvoh/7/kyt/9wyr289Fgveo3JufWaX/8/B/V9u0ByFvsvISQtQQ96NORcboeFJPtaW/dbaXLezFZpJIKc0l5xketfBZF15tl6vWy9Dvp8smyM3L4i65fZ8iK5f5tNX51Wc/5USM67yGNK5faO0ElBTch5vr0hzexrzo6SrnZCcDYhhJjMaX15ZztGdLDpcwI519KWz1veEsj5fBmVZdqWX3uZumm0e2bt7eUuBC39dLc3dOKLH93jRWVd+XDfPO9+FOV81Otl3qgsGhXxCQv8+Vpf/s1ny9wry1LeRaDj3kq6+6aXefl4r3P7ZLlOay169cv5geDzpYf1nne12zPtWxD2dUIy55iu//udJO0T/gX+TayzNrhIvM7lfNCJ5FxLWkKPaWWlMItFpselx/7Ya1TGJYtk3mjZ1nDJ1EDOJbfb9OC09twbkvOv2fOsspIXr+zFstKeBzknhMReziu6IDScQ2Wl7kSkj+gS1QtCV9poLXe/nHQzVqZO+Df9/O0kck4IqeljeljOm8ZNzveUK9aWmvTQhaEB/SU/0K8EZNnbWsdutdzBdl8OyXk/K2u5L7wBWWdmSM67a7lNOLLNLTpii5XhtKrmspYie3Pa2Ydv59CBmxCSuelqFxDqQfw0O5C3s/s9akPOtZxl0vr/OppXNz/sPU6HVdT7cRut5cEZSffvLyXdT14rn817/J5znf7On2q0rKW7HeM7WYLjPcd8Qur/8Tw4pp9ux3TtmG1uZdlBWUv85Fz4kcn1g1rGoutqCYpe5GnbmK4959pjLnfP1eeR+0fsub5s9eVLrJ78Oyrjsq1Hgh9ISlT8I0SJWrggVAVdh9fSIdLa2gdwe0JIRqedpY2dwBdb50AH64E55QtCP0vO0xPH0Vo0U5YkjxtKMZxaviC0gx3n23K8JyTj0jZ0TG9uJS0NI3VB6EnIeZ7I9EMy/3Ag1HpBqEmt0keWbQyWWXnLWJveYOt0lfvzQ+uUaAlMHch5ZUMphofbaU4IyegEw+01seNDc5M5/Wr0opoY57w+yvmT7/hyrr8GWhdyXsWhFNnfCanfx/Jmacf0RuZ/+aFe81r/QaLqJM++1m19gmXtQvO62FcIYYptfl3AjxARQk72R4jaWM3iSct5baU25TyqqeRHiILeMo73hGTuDxHlm//V+o8QwWcLenZI1PkpZ0JIZT/3nG9C18rKIy6Mspgj5+UFXd6vL1hJSzP7YM7jeE9IRh/Ts9OCmAMAxIxc63UpRs7jF3m/zrNvcIvsm5AcdmkAAAAA5Bw5R84BAAAAADlHzpFzAAAAAOQcOUfOAQAAAAA5R86RcwAAAADkHDlHzgEAAAAAOUfOkXMAAAAA5Bw5R84BAAAAADn/bDkf8QJyjpwDAAAA1C85159/7yrpEx85H+jumdHXjXgxo+X8XOQcAAAAoP7JeQtJZ0mvuMj5/fMGupEi5//x569kspz3kLSXNJXkI+cAAAAA8UZlrlDSXNJR0jMOcj520WD3wLuD3L0zL3f/OSWj5fxMSRtJE+QcAAAAoH7IuZZDaFmE9sB2l1woGSi5WnKd5CbJzRHMcGvbjZIbbHp4aPktEW33yf6t10uukQyVfEVPpBL+tx16vUAjSZ4km10aAAAAIN5yrj2ujU3yVPa0jvkiyVclg0wGr4hYhtntUJsOboeFll8ZwXafbPTvGyzpJ7lEcn7C7zXXE6pmCb80CTkHAAAAiDkqc0HdufaetzFBPzvh98xeIOmT8HvTo5SL7PbiCuZdZPMvimC7TyW9Tcr15ElH1tELQVvaiVVQ0oKcAwAAAMRczoPe84Ym6K1M/DpJupgInhHhnJmWM0K39SX6HnS1E6cOdhKlF/FqrXmhnWAh5wAAAAAxJytxrPdcBV170BubpKv8ac9ssQl7VBK0p3XotnXofvp69SXF9n5oGYuOztLIxDwvJOZZ7NIAAAAA8SY7cawHXUWvwKRPRb1hRNOogvuNKllWn9LA3psCO5nKRcwBAAAA6h9ZaZKeY+IXl+Sl3dbn5ISEPJByxBwAAACgHgo6iWcAAE6K/w9cZlqkCNlgBQAAAABJRU5ErkJggg==)

- EatWhatYouKill：这是 Jetty 对 ExecuteProduceConsume 策略的改良，在线程池线程充足的情况下等同于 ExecuteProduceConsume；当系统比较忙线程不够时，切换成 ProduceExecuteConsume 策略。为什么要这么做呢，原因是 ExecuteProduceConsume 是在同一线程执行 I/O 事件的生产和消费，它使用的线程来自 Jetty 全局的线程池，这些线程有可能被业务代码阻塞，如果阻塞得多了，全局线程池中的线程自然就不够用了，最坏的情况是连 I/O 事件的侦测都没有线程可用了，会导致 Connector 拒绝浏览器请求。于是 Jetty 做了一个优化，在低线程情况下，就执行 ProduceExecuteConsume 策略，I/O 侦测用专门的线程处理，I/O 事件的处理扔给线程池处理，其实就是放到线程池的队列里慢慢处理。

分析了这几种线程策略，我们再来看看 Jetty 是如何实现 ExecutionStrategy 接口的。答案其实就是实现 produce 接口生产任务，一旦任务生产出来，ExecutionStrategy 会负责执行这个任务。

```
private class SelectorProducer implements ExecutionStrategy.Producer
{
    private Set<SelectionKey> _keys = Collections.emptySet();
    private Iterator<SelectionKey> _cursor = Collections.emptyIterator();

    @Override
    public Runnable produce()
    {
        while (true)
        {
            // 如何 Channel 集合中有 I/O 事件就绪，调用前面提到的 Selectable 接口获取 Runnable, 直接返回给 ExecutionStrategy 去处理
            Runnable task = processSelected();
            if (task != null)
                return task;

           // 如果没有 I/O 事件就绪，就干点杂活，看看有没有客户提交了更新 Selector 的任务，就是上面提到的 SelectorUpdate 任务类。
            processUpdates();
            updateKeys();

           // 继续执行 select 方法，侦测 I/O 就绪事件
            if (!select())
                return null;
        }
    }
 }
```

SelectorProducer 是 ManagedSelector 的内部类，SelectorProducer 实现了 ExecutionStrategy 中的 Producer 接口中的 produce 方法，需要向 ExecutionStrategy 返回一个 Runnable。在这个方法里 SelectorProducer 主要干了三件事情

1. 如果 Channel 集合中有 I/O 事件就绪，调用前面提到的 Selectable 接口获取 Runnable，直接返回给 ExecutionStrategy 去处理。
2. 如果没有 I/O 事件就绪，就干点杂活，看看有没有客户提交了更新 Selector 上事件注册的任务，也就是上面提到的 SelectorUpdate 任务类。
3. 干完杂活继续执行 select 方法，侦测 I/O 就绪事件。

## 参考资料

- [Jetty 官方网址](http://www.eclipse.org/jetty/index.html)
- [Jetty Github](https://github.com/eclipse/jetty.project)
- [Jetty wiki](http://wiki.eclipse.org/Jetty/Reference/jetty-env.xml)
