---
---
title: 配置redis一直启动
tags: Redis
date: 2021-09-18
updated: 2021-09-18
categories: Redis
ai: true
---
# 配置redis一直启动

1. 进入 cmd窗口

2. 在进入redis的安装目录

3. 输入：`redis-server --service-install redis.windows.conf --loglevel verbose` ( 安装redis服务 )

4.  输入：`redis-server --service-start` ( 启动服务 )

5. 输入：`redis-server --service-stop` （停止服务） 