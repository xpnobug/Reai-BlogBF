---
---
ai: true
categories:
- 教程
date: 2021-06-1
tags:
- 教程
title: 端口号占用使用cmd解决
updated: 2023-9-7T21:20:52.964+8:0
---
**以杀掉8080为案例**

* 第一种：netstat -ano

```cmd
   输入netstat -ano

   找到8080端口

   记住对应的  PID

   taskkill /pid -f 杀掉端口
```

推荐

* 第二种：netstat -aon|findstr “8081”

```cmd
直接输入netstat -aon|findstr "8081"并回车

输入taskkill /pid  -f 杀掉端口 
```
