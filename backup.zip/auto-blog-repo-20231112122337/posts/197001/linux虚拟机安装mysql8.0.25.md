---
---
title: linux虚拟机安装mysql-8.0.25
date: 2021-09-28
updated: 2021-09-28
tags:
- Linux
- Mysql
- 教程
categories: 
- Linux
ai: true
---
 
# linux虚拟机安装mysql-8.0.25

### mysql未启动错误

```
[root@localhost ~]# mysql -u root -p
Enter password:
ERROR 2002 (HY000): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2)
```

**1、查看mysql服务是否在运行：**

- 端口是否打开 `lsof -i:3306`

  ```
  [root@localhost ~]# lsof -i:3306
  ```

**2.mysqld服务是否正在运行** `service mysqld status`

```
[root@localhost ~]# service mysqld status
 ERROR! MySQL is not running
```

**3.启动mysql**  `service mysql start`

```
[root@localhost ~]# service mysql start
Starting MySQL.. SUCCESS!

//查看状态
[root@localhost ~]# service mysqld status
 SUCCESS! MySQL running (4571)
 
 //看mysql服务是否在运行
[root@localhost ~]# lsof -i:3306
COMMAND  PID  USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
mysqld  4571 mysql   23u  IPv6  50765      0t0  TCP *:mysql (LISTEN)

```



### 下载

- 在线下载

  ```
  wget https://dev.mysql.com/get/Downloads/mysql-8.0.25-linux-glibc2.12-x86_64.tar.xz
  ```

  

- 访问 https://downloads.mysql.com/archives/community/ 下载

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632891757000.png)



### 在本地下载完共享文件到虚拟机

1.设置

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632891782000.png)

2.选择要共享的文件夹

![image-20210927231742221](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1632891867000.png)



# 卸载

查看是否存在`rpm -qa | grep mariadb`

```
[root@localhost ~]# rpm -qa | grep mariadb
mariadb-libs-5.5.65-1.el7.x86_64
```

卸载失败 坑1 `rpm -e`

```
[root@localhost ~]# rpm -e mariadb-libs-5.5.65-1.el7.x86_64
错误：依赖检测失败：
        libmysqlclient.so.18()(64bit) 被 (已安裝) postfix-2:2.10.1-9.el7.x86_64 需要
        libmysqlclient.so.18(libmysqlclient_18)(64bit) 被 (已安裝) postfix-2:2.10.1-9.el7.x86_64 需要
```

强制卸载 `rpm -e --nodeps`

```
[root@localhost ~]# rpm -e --nodeps mariadb-libs-5.5.65-1.el7.x86_64
```

再次查看

```
[root@localhost ~]# rpm -qa | grep mariadb
```

# 获取共享文件

`ls /mnt/hgfs/文件夹名`

```
[root@localhost ~]# ls /mnt/hgfs/anzb
[root@localhost ~]# cd /mnt/hgfs/anzb
```

## 解压至/user/local

```
[root@localhost anzb]# tar -xvf mysql-8.0.25-linux-glibc2.12-x86_64.tar.xz -C /usr/local
[root@localhost anzb]# cd /usr/local

修改默认文件夹名称
[root@localhost local]# mv mysql-8.0.25-linux-glibc2.12-x86_64 ./mysql8.0.25
#: mv 当前文件名称 修改的文件夹名称
```



# 创建数据目录

```
1.创建存放数据文件夹
[root@localhost local]# mkdir -p /data/mysqldata/
2.创建用户组
[root@localhost local]# groupadd mysql
3.创建用户
[root@localhost local]# useradd -r -g mysql mysql
赋权限
##chown 用户名:用户组 -R /data/mysqldata
[root@localhost local]# chown mysql:mysql -R /data/mysqldata 
[root@localhost local]# chmod 750 /data/mysqldata/ -R
```

# 配置环境

`vim /etc/profile`

```
[root@localhost local]# vim /etc/profile
vim /etc/profile 
#如果系统不支持vim命令 使用下边这个
vi /etc/profile

#编辑,在文档最后一行 添加下边代码
# :export PATH=$PATH:MySQL解压路径/mysql8.0.25/bin:MySQL解压路径/mysql8.0.25/lib
export PATH=$PATH:/usr/local/mysql8.0.25/bin:/usr/local/mysql8.0.25/lib




```

## 编辑my.cnf 

windos版本的my.ini

```
#1. 进入编辑my.cnf文件
[root@localhost local]# vim /etc/my.cnf
```

```
[mysql]
# 客户端默认字符集
default-character-set=utf8mb4
[client]
port=3306
socket=/var/lib/mysql/mysql.sock
[mysqld]
port=3306
server-id=3306
user=mysql
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
# 设置mysql的安装目录
basedir=/usr/local/mysql8.0.25 #自己的安装路径
# 设置mysql数据库的数据的存放目录
datadir=/data/mysqldata/mysql  #你自己创建的数据库文件存放路径
log-bin=/data/mysqldata/mysql/mysql-bin
innodb_data_home_dir=/data/mysqldata/mysql
innodb_log_group_home_dir=/data/mysqldata/mysql
character-set-server=utf8mb4
lower_case_table_names=1
autocommit=1
# Disabling symbolic-links is recommended to prevent assorted security risks
symbolic-links=0
# Settings user and group are ignored when systemd is used.
# If you need to run mysqld under a different user or group,
# customize your systemd unit file for mariadb according to the
# instructions in http://fedoraproject.org/wiki/Systemd

[mysqld_safe]
#设置mysql数据库的日志及进程数据的存放目录
log-error=/data/mysqldata/mysql/mysql.log
pid-file=/data/mysqldata/mysql/mysql.pid

```

# 初始化MySQL

会获取到临时的密码用于第一次登录mysql

`./mysqld --defaults-file=/etc/my.cnf --basedir=/usr/local/mysql8.0.25/ --datadir=/data/mysqldata/mysql --user=mysql --initialize`

```
[root@localhost local]# cd /usr/local/mysql8.0.25/bin/
[root@localhost bin]# ./mysqld --defaults-file=/etc/my.cnf --basedir=/usr/local/mysql8.0.25/ --datadir=/data/mysqldata/mysql --user=mysql --initialize
2021-09-27T07:47:49.269631Z 0 [Warning] [MY-011070] [Server] 'Disabling symbolic links using --skip-symbolic-links (or equivalent) is the default. Consider not using this option as it' is deprecated and will be removed in a future release.
2021-09-27T07:47:49.270101Z 0 [System] [MY-013169] [Server] /usr/local/mysql8.0.25/bin/mysqld (mysqld 8.0.25) initializing of server in progress as process 70235
2021-09-27T07:47:49.301585Z 1 [System] [MY-013576] [InnoDB] InnoDB initialization has started.
2021-09-27T07:47:50.139914Z 1 [System] [MY-013577] [InnoDB] InnoDB initialization has ended.
2021-09-27T07:47:51.785857Z 6 [Note] [MY-010454] [Server] A temporary password is generated for root@localhost: g/zf(ay.s13Z
```

```
./mysqld --defaults-file=/etc/my.cnf --basedir=/usr/local/mysql8.0.25/ --datadir=/data/mysqldata/mysql --user=mysql --initialize
#参数详解
--defaults-file=/etc/my.cnf 指定配置文件（一定要放在最前面，至少 --initialize 前面）
--user=mysql 指定用户（很关键）
--basedir=/usr/local/mysql8.0.25/ 指定安装目录
--datadir=/data/mysqldata/mysql/ 指定初始化数据目录
 
```

## 启动MySQL

解释：

```
# 1.复制 mysql.server 文件
cp /home/mysql-8.0.25/support-files/mysql.server /etc/init.d/mysql
cp /home/mysql-8.0.25/support-files/mysql.server /etc/init.d/mysqld
# 2.赋予权限
chown 777 /etc/my.cnf
chmod +x /etc/init.d/mysql
chmod +x /etc/init.d/mysqld
# 3.检查一下/var/lib/mysql是否存在，否进行创建
mkdir /var/lib/mysql #目录和my.cnf保持一致
# 4.赋予权限
chown -R mysql:mysql /var/lib/mysql/ #目录和my.cnf保持一致
# 5.启动数据库
service mysql start #或者 systemctl mysql start 
```

步骤：

```
[root@localhost bin]# cp /usr/local/mysql8.0.25/support-files/mysql.server /etc/init.d/mysql
[root@localhost bin]# cp /usr/local/mysql8.0.25/support-files/mysql.server /etc/init.d/mysqld
[root@localhost bin]# chown 777 /etc/my.cnf
[root@localhost bin]# chmod +x /etc/init.d/mysql
[root@localhost bin]# chmod +x /etc/init.d/mysqld
[root@localhost bin]# mkdir /var/lib/mysql
[root@localhost bin]# chown -R mysql:mysql /var/lib/mysql/

//启动mysql
[root@localhost bin]# service mysql start
```

启动成功

```
Starting MySQL.Logging to '/data/mysqldata/mysql/mysql.log'.
. SUCCESS!
```

## mysql数据库设置

登录mysql ,修改初始密码

```
mysql -u root -p
或
#进入安装目录
cd /home/mysql-8.0.25/bin
# 执行命令
./mysql -uroot -p
输入临时密码
```

```
[root@localhost bin]# ./mysql -uroot -p
Enter password:
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 8
Server version: 8.0.25

Copyright (c) 2000, 2021, Oracle and/or its affiliates.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
```



```
# 修改root密码 修改root用户只能本地连接
ALTER USER 'root'@'localhost' IDENTIFIED with mysql_native_password BY '新密码';
#刷新权限
flush privileges; 

mysql> ALTER USER 'root'@'localhost' IDENTIFIED with mysql_native_password BY 'root';
Query OK, 0 rows affected (0.00 sec)

mysql> flush privileges;
Query OK, 0 rows affected (0.01 sec)
```



# 设置远程连接

1.查看各用户的host， 更新*root*用户，允许任何IP 登录

```
use mysql

select user,host from user;

update user set host='%' where user='root'; ##root表示想要被连接的数据库的用户名其中“%”表示允许所有机器能访问root用户
```



2.**改变加密方式**

```
update user set plugin='mysql_native_password' where user='root'; 

flush privileges;#刷新权限
```



3.**远程连接授权**

```
grant all privileges on *.* to root@'%';

flush privileges; #刷新权限
```

**查看所有数据库**
`show databases`

4.**退出mysql** :

`exit`



5.**开放端口3306**

查看3306端口

```
losof -i:3306
lsof -i:3306
```

查看mysql

```
ps -ef | grep mysql
```




```
firewall-cmd --add-port=3306/tcp//添加端口

firewall-cmd --list-ports//端口列表

systemctl status firewalld//查看防火墙端口
```



6.**使用SQLyog 或 Navicat for MySQL 连接** 



# 设置mysql开机自启动

```
#1.查看是否有mysql服务chkconfig --list
#2.进入mysql软件目录，复制mysql.server文件到 /etc/rc.d/init.d目录下cp   /home/mysql-8.0.25/support-files/mysql.server  /etc/rc.d/init.d/mysql
#3.给/etc/rc.d/init.d/mysql赋权可执行权限chmod  +x  /etc/rc.d/init.d/mysql
#4.添加mysql服务chkconfig --add mysql
#5.使mysql服务开机自启chkconfig --level 345 mysql on
#6.查看MySQL服务 ,重启服务器，测试是否成功。chkconfig --list
```

 

（完）