---
---
abbrlink: ''
categories: []
cover: 
date: '2022-11-25 16:28:13'
tags: 
- 记录
title: mysql记录
updated: '2022-11-25 16:28:15'
ai: true
---
**Mysql中的FIELD函数**

1. SQL中查询结果集进行指定顺序排序

```mysql
select * from table where id IN (3,6,9,1,2,5,8,7) order by field(id,3,6,9,1,2,5,8,7);
```
