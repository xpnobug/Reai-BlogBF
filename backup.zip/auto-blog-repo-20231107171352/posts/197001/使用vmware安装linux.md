---
---
ai: true
categories:
- Linux
date: '2021-09-07'
tags:
- Linux
title: 使用 vmware 安装linux
updated: 2023-9-7T21:17:16.525+8:0
---
# 安装vmware

直接腾讯软件中心下载 https://pc.qq.com/search.html#!keyword=vmware
一直下一步，选一个目录安装即可

```
官网下载后用这个秘钥 
YG5H2-ANZ0H-M8ERY-TXZZZ-YKRV8 
UG5J2-0ME12-M89WY-NPWXX-WQH88 
UA5DR-2ZD4H-089FY-6YQ5T-YPRX6 
GA590-86Y05-4806Y-X4PEE-ZV8E0 
ZF582-0NW5N-H8D2P-0XZEE-Z22VA 
YA18K-0WY8P-H85DY-L4NZG-X7RAD
```

![安装成功页面](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631030261000.png)

# 安装linux

![第一步](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631030454000.png)

![第二步](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631030589000.png)

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631031007000.png)

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631031157000.png)

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631031370000.png)

配置处理器 2核4G 自配置 ，会动态调整

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631031643000.png)

配置内存

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631031886000.png)

默认

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032035000.png)

推荐  下一步

推荐  下一步

创建虚拟磁盘

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032212000.png)

指定存盘容量

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032294000.png)

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032383000.png)

准备创建

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631044306000.png)

配置完之后

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032490000.png)

# **关键：挂载系统**

```
双击CD/DVD(IDE)		选择下载的系统文件
```


![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631032991000.png)

开启虚拟机
选择第一个，等待
![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034204000.png)

选择语言

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034220000.png)

找带有图标标记的内容进行下一步

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034246000.png)

直接点完成

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034264000.png)

返回点击开始安装

设置root密码

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034284000.png)

密码太短点击两次完成
![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034306000.png)

安装完成 重启

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631034334000.png)

登录完成

![](https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1631041094000.png)
