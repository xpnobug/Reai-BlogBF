---
---
abbrlink: ''
date: '2021-09-28 00:00:00'
tags: 
- Linux
- 教程
categories: Linux
title: linux虚拟机安装jdk1.8
updated: '2022-10-30 01:29:01'
ai: true
---
# linux虚拟机安装jdk1.8

```
# 检测当前系统是否存在java环境！ java -version 

# 如果有的话就需要卸载 

# rpm -qa|grep jdk # 检测JDK版本信息 
# rpm -qa | grep java  # 检测java版本信息 

# rpm -e --nodeps jdk_ 

# 卸载完毕后即可安装jdk

# 配置环境变量
```

# 1、下载jdk

> https://www.oracle.com/java/technologies/downloads/#java8

# 2、卸载原先的 OpenJDK

**查看版本信息**

```
java -version 
```

**查看系统安装的java和jdk信息**

```
rpm -qa | grep java  
rpm -qa | grep jdk 
```

**移除 OpenJDK**

```
yum -y remove java java-1.4.2-gcj-compat-1.4.2.0-40jpp.115 
```

**批量移除**

批量卸载所有名字包含jdk的已安装程序

```
rpm -qa | grep jdk | xargs rpm -e --nodeps
```

批量卸载所有名字包含java的已安装程序。

```
rpm -qa | grep java | xargs rpm -e --nodeps 
```

# 3、解压

然后使用 xftp 工具把安装包上传到 opt 目录下，解压到/usr/local 目录，

`tar -zxvf jdk 的文件名 –C /usr/local`

```
tar -zxvf jdk-8u301-linux-x64.tar.gz -C /usr/local
```

切换到/usr/local 目录，

更改文件夹名称，

```
mv jdk-8u301-linux-x64 ./java
```

# 4、配置环境变量

`vim /etc/profile`  i 添加

```
export JAVA_HOME=/usr/local/java
export PATH=$PATH:$JAVA_HOME/bin
```

`esc `退出编辑

`shift+zz`保存

**需要让刚才添加的内容生效**

`source /etc/profile`

# 5、查看jdk版本信息

`java -version`

```
java version "1.8.0_301"
Java(TM) SE Runtime Environment (build 1.8.0_301-b09)
Java HotSpot(TM) 64-Bit Server VM (build 25.301-b09, mixed mode)
```
