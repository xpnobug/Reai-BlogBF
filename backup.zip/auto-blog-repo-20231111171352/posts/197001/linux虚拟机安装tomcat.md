---
---
title:  linux虚拟机安装tomcat
date: 2021-10-09
updated: 2021-10-09
cover: https://cdn.jsdelivr.net/gh/xpnobug/CDN@main/img/hpp_upload/1633774464000.svg
tags:
- Linux
- Tomcat
- 教程
categories:
- Linux
ai: true
---
  #  linux虚拟机安装tomcat



# 下载

```
wget https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.54/bin/apache-tomcat-9.0.54.tar.gz

wget --no-check-certificate https://dlcdn.apache.org/tomcat/tomcat-9/v9.0.54/bin/apache-tomcat-9.0.54.tar.gz
```

# 解压

```
tar -zxvf apache-tomcat-9.0.54.tar.gz -C /usr/local
```

# 启动

```
//启动tomcat
cd /usr/local/apache-tomcat
./bin/startup.sh
```

# 本地访问

```
ps -ef | grep tomcat
lsof -i:8080

systemctl stop firewalld.service  //开启防火墙
systemctl start firewalld.service //关闭防火墙

//本地访问
firewall-cmd --zone=public --add-port=80/tcp --permanent //永久添加80端口
firewall-cmd --zone=public --add-port=8080/tcp --permanent //永久添加8080端口

firewall-cmd --reload 			//防火墙重新加载配置
firewall-cmd --list-ports		//端口列表
systemctl status firewalld		//查看防火墙端口
 
 
```
 