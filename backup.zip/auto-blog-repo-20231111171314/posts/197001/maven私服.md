---
---
categories:
- - maven
date: '2023-06-03T16:46:40.210895+08:00'
excerpt: 这篇文章介绍了在maven的setting文件中如何在servers下创建server，包括设置id、username和password等参数。通过创建server，可以使maven在执行构建任务时连接到指定的远程仓库。同时，还介绍了一些常见的server配置示例和注意事项。
tags:
- maven
title: maven私服
updated: 2023-6-3T16:48:31.329+8:0
---
**maven的setting文件中**

**在servers下**

**创建**

```
    <server>
      <id>github</id>
      <username>用户名</username>
      <password>密码</password>
    </server>
```

```
<build>
    <plugins>
        <!--maven-deploy-plugin maven发布插件-->
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-deploy-plugin</artifactId>
            <version>2.8.2</version>
            <configuration>
                <altDeploymentRepository>
                    internal.repo::default::file://${project.build.directory}/maven-repo
                </altDeploymentRepository>
            </configuration>
        </plugin>

        <!--site-maven-plugin-->
        <plugin>
            <groupId>com.github.github</groupId>
            <artifactId>site-maven-plugin</artifactId>
            <version>0.12</version>
            <configuration>
                <message>常用依赖, version: ${project.version}</message><!--提交信息-->
                <noJekyll>true</noJekyll>
                <outputDirectory>${project.build.directory}/maven-repo</outputDirectory>
                <!--本地jar地址-->
                <branch>refs/heads/main</branch><!--分支的名称-->
                <merge>true</merge>
                <includes>
                    <include>**/*</include>
                </includes>
                <repositoryName>maven-repo</repositoryName><!--对应github上创建的仓库名称 name-->
                <repositoryOwner>qwe</repositoryOwner><!--github 仓库所有者即登录用户名-->
            </configuration>
            <executions>
                <execution>
                    <goals>
                        <goal>site</goal>
                    </goals>
                    <phase>deploy</phase>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```
